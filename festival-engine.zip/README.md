# Festival Engine

Motor reutilizable para apps de programación de festivales de cine.
Single HTML, vanilla JS, sin dependencias externas, offline-first via PWA.

## Uso rápido

```bash
# Construir FICCI 65
node build.js ficci-65

# Construir Jardín 2026
node build.js jardin-2026
```

Output en `dist/`: `index.html` + `manifest.json` + `sw.js` → subir a GitHub Pages.

## Estructura

```
festival-engine/
├── src/
│   ├── styles.css              CSS del engine (compartido)
│   ├── template.html           Esqueleto HTML con tokens {{VARIABLE}}
│   └── engine/
│       ├── utils.js            Funciones puras (toMin, screensConflict, etc.)
│       ├── state.js            Estado (watchlist, loadState, toggleWL, etc.)
│       ├── algo.js             Algoritmo (computeScenarios, getSuggestions)
│       └── render/
│           ├── seleccion.js    Tab Selección
│           ├── miplan.js       Tab Mi Plan
│           ├── planner.js      Tab Planear
│           ├── cartelera.js    Tab Cartelera (grid principal)
│           └── main.js         Navegación + renderAgenda + init
├── festivals/
│   ├── ficci-65/
│   │   ├── config.js           Identidad, fechas, colores, helpers de poster
│   │   └── data.js             FILMS[], POSTERS{}, COLLAGES{}
│   └── jardin-2026/
│       ├── config.js           ← Editar con datos del festival
│       └── data.js             ← Rellenar con la programación
└── build.js                    Script de build (Node.js, sin dependencias)
```

## Crear un festival nuevo

1. `cp -r festivals/jardin-2026 festivals/mi-festival-2027`
2. Editar `festivals/mi-festival-2027/config.js` — identidad, fechas, colores
3. Rellenar `festivals/mi-festival-2027/data.js` — array `FILMS[]` con la programación
4. `node build.js mi-festival-2027`
5. Subir `dist/` a GitHub Pages

## Tokens del template

| Token | Descripción |
|-------|-------------|
| `{{FESTIVAL_TITLE}}` | Título de la pestaña del browser |
| `{{FESTIVAL_NAME}}` | Nombre corto del festival |
| `{{FESTIVAL_CITY}}` | Ciudad |
| `{{FESTIVAL_DATES_DISPLAY}}` | Fechas legibles ("14 – 19 Abril 2026") |
| `{{FESTIVAL_LOGO_URL}}` | URL del logo |
| `{{FESTIVAL_COLOR}}` | Color primario (hex) |
| `{{CSS}}` | CSS completo del engine |
| `{{JS}}` | JS completo (data + config + engine) |

## Estructura de FILMS[]

```js
{
  "title": "Nombre de la película",
  "title_en": "English title",
  "country": "Colombia/Francia",
  "flags": "🇨🇴🇫🇷",
  "duration": "90 min",
  "day": "Viernes",           // clave en FESTIVAL_DATES{}
  "date": 17,                 // número del día del mes
  "time": "19:00",
  "venue": "Teatro Adolfo Mejía",
  "section": "🏆 Competencia",
  "day_order": 3,             // 0 = primer día del festival
  "is_cortos": false,
  "film_list": []             // para programas: [{title, country, duration}]
}
```

## Fixes críticos (no remover en refactors)

Ver `grep "FIX CRÍTICO"` en los archivos del engine. Son 4 fixes con comentario
de bloqueo — cada uno tiene su razón documentada.
