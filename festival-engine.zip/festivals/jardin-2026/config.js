// ── Festival de Cine de Jardín 2026 — Config ──
// Copiado del template de FICCI 65. Actualiza los valores de abajo.
// Luego provee data.js con el array FILMS[] y ejecuta: node build.js jardin-2026

// ── Identity ──
const FESTIVAL_ID      = 'jardin-2026';
const FESTIVAL_TITLE   = 'Festival de Cine de Jardín 2026';
const FESTIVAL_NAME    = 'Cine Jardín';
const FESTIVAL_CITY    = 'Jardín, Antioquia';
const FESTIVAL_DATES_DISPLAY = 'Septiembre 2026';   // ← Actualizar cuando se confirmen fechas
const FESTIVAL_LOGO_URL = '';                         // ← URL del logo del festival
const FESTIVAL_LOGO_FALLBACK_HTML = 'Cine <em>Jardín</em>';
const FESTIVAL_COLOR   = '#2D7D46';   // Verde jardín — ajustar al branding real
const FESTIVAL_BG      = '#1A1F1B';

// ── Poster helpers (no cambiar la lógica, solo las constantes) ──
const TMDB_IMG = "https://image.tmdb.org/t/p/w185";
const FESTIVAL_POSTER_URL = '';   // ← Logo del festival para programas sin poster propio
function getPosterSrc(title, isCortos) {
  if (isCortos) {
    const imgs = COLLAGES[title];
    if (imgs && imgs.length) return imgs[0];
    return FESTIVAL_POSTER_URL;
  }
  return CUSTOM_POSTERS[title] || (POSTERS[title] ? TMDB_IMG + POSTERS[title] : null);
}
const LB_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="13" height="13" style="display:block;flex-shrink:0"><rect width="64" height="64" rx="9" fill="#2C3440"/><circle cx="21" cy="32" r="12" fill="#00B020" opacity=".9"/><circle cx="32" cy="32" r="12" fill="#3CBEDB" opacity=".85"/><circle cx="43" cy="32" r="12" fill="#FF8000" opacity=".9"/></svg>`;

// ── Festival date map — ACTUALIZAR con fechas reales ──
// Formato: 'NombreDía': 'YYYY-MM-DD'
// DAY_KEYS en state.js debe coincidir con estas claves
const FESTIVAL_DATES = {
  'Jueves':  '2026-09-10',   // ← Fechas de ejemplo — actualizar
  'Viernes': '2026-09-11',
  'Sábado':  '2026-09-12',
  'Domingo': '2026-09-13',
};

