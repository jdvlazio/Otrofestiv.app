// ── Festival de Cine de Jardín 2026 — Data ──
// Sustituye estos arrays con la programación real del festival.

const FILMS = [
  // Ejemplo de estructura — copiar para cada función:
  // {
  //   "title": "Título de la película",
  //   "title_en": "English title (opcional)",
  //   "country": "Colombia",
  //   "flags": "🇨🇴",
  //   "duration": "90 min",
  //   "day": "Viernes",           // debe coincidir con clave en FESTIVAL_DATES
  //   "date": 11,                 // día del mes
  //   "time": "18:00",
  //   "venue": "Teatro Municipal",
  //   "section": "🏆 Competencia",
  //   "day_order": 1,             // 0=primer día, 1=segundo, etc.
  //   "is_cortos": false,
  //   "film_list": []             // para programas de cortos: [{title, country, duration}]
  // },
];

// Posters de TMDB — { "Título": "/path.jpg" }
const POSTERS = {};

// Posters personalizados — { "Título": "https://url-completa.jpg" }
const CUSTOM_POSTERS = {};

// Imágenes de cortos individuales — { "Título corto": "https://url.jpg" }
const SHORT_IMGS = {};

// Collages para programas de cortos — { "Nombre programa": ["url1", "url2"] }
const COLLAGES = {};
