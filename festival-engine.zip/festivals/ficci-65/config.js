// ── FICCI 65 — Festival config (identity, dates, poster helpers) ──
// To create a new festival: copy this file, update values, provide data.js

// ── Identity (used by build.js for <title>, manifest.json, sw.js cache key) ──
const FESTIVAL_ID      = 'ficci-65';
const FESTIVAL_TITLE   = 'FICCI 65 — Programación';
const FESTIVAL_NAME    = 'FICCI 65';
const FESTIVAL_CITY    = 'Cartagena de Indias';
const FESTIVAL_DATES_DISPLAY = '14 – 19 Abril 2026';
const FESTIVAL_LOGO_URL = 'https://ficcifestival.com/sites/default/files/2026-02/logo-ficci65_2.png';
const FESTIVAL_LOGO_FALLBACK_HTML = 'FICCI <em>65</em>';
const FESTIVAL_COLOR   = '#E85A1E';   // --orange in CSS
const FESTIVAL_BG      = '#1C1C1C';   // --bg in CSS

const TMDB_IMG="https://image.tmdb.org/t/p/w185";
const FICCI_POSTER_URL='https://ficcifestival.com/sites/default/files/2026-02/logo-ficci65_2.png';
function getPosterSrc(title,isCortos){
  if(isCortos){
    const imgs=COLLAGES[title];
    if(imgs&&imgs.length) return imgs[0];
    return FICCI_POSTER_URL;
  }
  return CUSTOM_POSTERS[title]||(POSTERS[title]?TMDB_IMG+POSTERS[title]:null);
}
const LB_SVG=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="13" height="13" style="display:block;flex-shrink:0"><rect width="64" height="64" rx="9" fill="#2C3440"/><circle cx="21" cy="32" r="12" fill="#00B020" opacity=".9"/><circle cx="32" cy="32" r="12" fill="#3CBEDB" opacity=".85"/><circle cx="43" cy="32" r="12" fill="#FF8000" opacity=".9"/></svg>`;

// Festival date map
const FESTIVAL_DATES={
  'Martes':'2026-04-14','Miércoles':'2026-04-15','Jueves':'2026-04-16',
  'Viernes':'2026-04-17','Sábado':'2026-04-18','Domingo':'2026-04-19'
};

// Check if a screening has passed (with 10 min grace)
