// ── ENGINE: Utility functions ──
// screeningPassed, time helpers, screensConflict, travelMins, normalize
// No festival-specific data — safe to reuse across festivals

function screeningPassed(s){
  const dateStr=FESTIVAL_DATES[s.day];
  if(!dateStr) return false;
  const screeningTime=new Date(`${dateStr}T${s.time}:00`);
  screeningTime.setMinutes(screeningTime.getMinutes()+10); // 10 min grace
  return new Date()>screeningTime;
}
function dayFullyPassed(day){
  const dateStr=FESTIVAL_DATES[day];
  if(!dateStr) return false;
  // Day passed if last function of that day has passed
  const dayFilms=FILMS.filter(f=>f.day===day);
  if(!dayFilms.length) return false;
  const lastTime=dayFilms.reduce((max,f)=>f.time>max?f.time:max,'00:00');
  const lastScreen=new Date(`${dateStr}T${lastTime}:00`);
  lastScreen.setMinutes(lastScreen.getMinutes()+10);
  return new Date()>lastScreen;
}
function isNowShowing(f){
  const dateStr=FESTIVAL_DATES[f.day];if(!dateStr) return false;
  const now=new Date();
  const start=new Date(`${dateStr}T${f.time}:00`);
  const dur=f.duration?parseInt(f.duration):90;
  const end=new Date(start.getTime()+dur*60000);
  return now>=start&&now<=end;
}
function isToday(day){
  const dateStr=FESTIVAL_DATES[day];
  if(!dateStr) return false;
  const today=new Date().toISOString().slice(0,10);
  return dateStr===today;
}

const VENUES={
  'Teatro Adolfo Mejía':{ico:'🎭',short:'Teatro Adolfo Mejía'},
  'CC Bocagrande':      {ico:'🎬',short:'CC Bocagrande'},
  'CC Caribe Plaza':    {ico:'🍿',short:'CC Caribe Plaza'},
  'Auditorio nido':     {ico:'🪺',short:'Auditorio nido'},
  'Plaza Proclamación': {ico:'🌟',short:'Plaza Proclamación'},
  'C. Convenciones':    {ico:'🏟️',short:'C. de Convenciones'},
};
function vcfg(v){
  if(v.includes('Teatro Adolfo'))  return VENUES['Teatro Adolfo Mejía'];
  if(v.includes('Bocagrande'))     return VENUES['CC Bocagrande'];
  if(v.includes('Caribe Plaza'))   return VENUES['CC Caribe Plaza'];
  if(/nido/i.test(v))              return VENUES['Auditorio nido'];
  if(v.includes('Proclamación'))   return VENUES['Plaza Proclamación'];
  return VENUES['C. Convenciones'];
}
function sala(v){const m=v.match(/Sala\s*(\d+)/);return m?'Sala '+m[1]:'';}
function toMin(t){const[h,m]=t.split(':').map(Number);return h*60+m;}
function parseDur(d){const m=d&&d.replace('~','').match(/(\d+)/);return m?parseInt(m[1]):90;}
function minToStr(m){
  const h=Math.floor(((m%1440)+1440)%1440/60),mn=((m%1440)+1440)%1440%60;
  return`${String(h).padStart(2,'0')}:${String(mn).padStart(2,'0')}`;
}
function screensConflict(a,b){
  if(a.day!==b.day) return false;
  const aS=toMin(a.time)-10,aE=toMin(a.time)+parseDur(a.duration)+10;
  const bS=toMin(b.time)-10,bE=toMin(b.time)+parseDur(b.duration)+10;
  return aS<bE&&bS<aE;
}
function travelMins(venueA,venueB){
  const g=v=>v.includes('Bocagrande')?'bog':v.includes('Caribe Plaza')?'cp':'centro';
  const g1=g(venueA),g2=g(venueB);
  if(g1===g2) return 0;
  if((g1==='bog'&&g2==='cp')||(g1==='cp'&&g2==='bog')) return 13;
  if(g1==='centro'||g2==='centro') return g1==='cp'||g2==='cp'?16:12;
  return 0;
}
function travelWarn(s1,s2){
  if(s1.day!==s2.day) return null;
  const travel=travelMins(s1.venue,s2.venue);
  if(travel===0) return null;
  const gap=toMin(s2.time)-(toMin(s1.time)+parseDur(s1.duration));
  if(gap<travel+10) return`▲ ~${travel} min en carro entre estas sedes`;
  return null;
}

// Normalize text for accent-insensitive search
function normalize(str){
  return str.normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase();
}

