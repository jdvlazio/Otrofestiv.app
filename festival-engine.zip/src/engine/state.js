// ── ENGINE: Application state ──
// State variables, localStorage persistence, watchlist/watched/priority mutations

// ── STATE ──
let watchlist=new Set();
let watched=new Set();
let prioritized=new Set();
const PRIO_LIMIT=3;
let savedAgenda=null;
let lastRemovedSlots=[]; // tracks up to 5 recently removed films
const MAX_REMEMBERED_SLOTS=5;
let activeMiPlanDay=null;
// ─────────────────────────────────────────────────────────────────────────────
// ⚠️  FIX CRÍTICO — NO REMOVER (Apr 2026)
// availability debe inicializarse aquí con los 6 días del festival.
// Sin esta inicialización, Planear lanza TypeError al acceder a
// availability[day].blocks y la pestaña no renderiza.
// ─────────────────────────────────────────────────────────────────────────────
let availability={
  'Martes':{blocks:[]},'Miércoles':{blocks:[]},'Jueves':{blocks:[]},
  'Viernes':{blocks:[]},'Sábado':{blocks:[]},'Domingo':{blocks:[]}
};

const MPLAN_START_H=10,MPLAN_END_H=24;
const MPLAN_TOTAL_MINS=(MPLAN_END_H-MPLAN_START_H)*60;
const MPLAN_PX_PER_MIN=52/60;
const MPLAN_DETAIL_H=MPLAN_TOTAL_MINS*MPLAN_PX_PER_MIN;

function mplanPx(min){return(min-MPLAN_START_H*60)*MPLAN_PX_PER_MIN;}
function mplanPct(min){return((min-MPLAN_START_H*60)/MPLAN_TOTAL_MINS*100);}
function mplanEndStr(t,d){const m=toMin(t)+d;return String(Math.floor(m/60)%24).padStart(2,'0')+':'+String(m%60).padStart(2,'0');}

function mplanBlockType(s){
  if(prioritized.has(s._title)) return'mp-priority';
  const f=FILMS.find(fi=>fi.title===s._title);
  if(f&&f.is_cortos) return'mp-program';
  return'mp-regular';
}


function selectMiPlanDay(idx){
  activeMiPlanDay=idx;
  renderAgenda();
}


function loadState(){
  try{
    const wl=localStorage.getItem('ficci65_wl'); if(wl) watchlist=new Set(JSON.parse(wl));
    const wt=localStorage.getItem('ficci65_watched'); if(wt) watched=new Set(JSON.parse(wt));
    const av=localStorage.getItem('ficci65_av3'); if(av){const p=JSON.parse(av);DAY_KEYS.forEach(d=>{if(p[d]) availability[d]=p[d];});}
    const sa=localStorage.getItem('ficci65_saved'); if(sa) savedAgenda=JSON.parse(sa);
    const pr=localStorage.getItem('ficci65_prio'); if(pr) prioritized=new Set(JSON.parse(pr));
    // Restore reserved slot — persists across refresh, button shows "＋ Añadir" (not "← Restaurar")
    const rs=localStorage.getItem('ficci65_lastslot');if(rs){try{const p=JSON.parse(rs);lastRemovedSlots=Array.isArray(p)?p:(p?[p]:[]);}catch(e){}}
  }catch(e){}
}
function saveWL(){try{localStorage.setItem('ficci65_wl',JSON.stringify([...watchlist]));}catch(e){}}
function saveWatched(){try{localStorage.setItem('ficci65_watched',JSON.stringify([...watched]));}catch(e){}}
function saveAV(){try{localStorage.setItem('ficci65_av3',JSON.stringify(availability));}catch(e){}}
function saveSavedAgenda(){try{localStorage.setItem('ficci65_saved',JSON.stringify(savedAgenda));}catch(e){}}
function savePrio(){try{localStorage.setItem('ficci65_prio',JSON.stringify([...prioritized]));}catch(e){}}
function saveLastSlot(){try{localStorage.setItem('ficci65_lastslot',JSON.stringify(lastRemovedSlots));}catch(e){}}

function updateAgTab(){
  // Count: in watchlist, not watched, and has future screenings
  const future=[...watchlist].filter(t=>{
    if(watched.has(t)) return false;
    return FILMS.some(f=>f.title===t&&!screeningPassed(f));
  });
  const el=document.getElementById('ag-cnt');if(el) el.textContent=future.length;
  const tab=document.getElementById('agtab');if(tab) tab.classList.toggle('on',activeView==='agenda');
}

function toggleWL(title,e){
  if(e) e.stopPropagation();
  if(watchlist.has(title)){
    // If film is in saved agenda, ask first
    if(savedAgenda&&savedAgenda.schedule.some(s=>s._title===title)){
      const confirmed=confirm(`"${title.length>40?title.slice(0,38)+'…':title}" está en tu Plan.\n\n¿Quitar también del Plan al quitarla de Selección?`);
      if(!confirmed) return; // user cancelled — touch nothing
      // Remove from saved agenda too
      savedAgenda.schedule=savedAgenda.schedule.filter(s=>s._title!==title);
      if(!savedAgenda.schedule.length) savedAgenda=null;
      saveSavedAgenda();
    }
    // Now safe to remove from watchlist
    watchlist.delete(title);watched.delete(title);prioritized.delete(title);
  }
  else{
    watchlist.add(title);watched.delete(title);
    showToast('♥ Añadida a Selección','info');
  }
  saveWL();saveWatched();updateCardState(title);updateAgTab();
  if(activeView==='agenda'){cachedResult=null;renderAgenda();}
}
function toggleWatched(title,e){
  if(e) e.stopPropagation();
  if(watched.has(title)) watched.delete(title);
  else watched.add(title);
  saveWatched();updateCardState(title);updateAgTab();
  if(activeView==='agenda'){cachedResult=null;renderAgenda();}
}
function updateCardState(title){
  const inWL=watchlist.has(title),inW=watched.has(title),inPrio=prioritized.has(title);
  document.querySelectorAll(`.card[data-title="${CSS.escape(title)}"]`).forEach(card=>{
    card.classList.toggle('in-wl',inWL&&!inW);
    card.classList.toggle('in-watched',inW);
    const wlBtn=card.querySelector('.wl-btn');
    const wBtn=card.querySelector('.w-btn');
    const prioBtn=card.querySelector('.prio-btn');
    if(wlBtn){wlBtn.textContent=inWL?'♥':'♡';wlBtn.classList.toggle('wl-on',inWL);wlBtn.title=inWL?'Quitar de Selección':'Añadir a Selección';}
    if(wBtn){wBtn.classList.toggle('w-on',inW);wBtn.title=inW?'Marcar como pendiente':'Marcar como vista';}
    if(prioBtn){prioBtn.classList.toggle('prio-on',inPrio);prioBtn.title=inPrio?'Quitar prioridad':'Priorizar';}
  });
}

// ── FUZZY SEARCH — accent insensitive ──
