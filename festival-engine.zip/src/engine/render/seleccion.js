// ── RENDER: Selección tab ──
// Fuzzy search, renderPrioStrip, renderFilmListHTML

function fuzzyMatch(query,title){
  const q=normalize(query),t=normalize(title);
  if(t.includes(q)) return{match:true,score:100+q.length};
  let qi=0;for(let i=0;i<t.length&&qi<q.length;i++) if(t[i]===q[qi]) qi++;
  if(qi===q.length) return{match:true,score:qi};
  return{match:false,score:0};
}
function searchFilms(query){
  if(!query||query.length<2) return[];
  const seen=new Set();
  return FILMS
    .map(f=>{
      const r1=fuzzyMatch(query,f.title);
      const r2=f.title_en?fuzzyMatch(query,f.title_en):{match:false,score:0};
      let r3={match:false,score:0};
      if(f.film_list&&f.film_list.length){
        for(const item of f.film_list){
          const r=fuzzyMatch(query,item.title);
          if(r.match&&r.score>r3.score) r3=r;
        }
      }
      return{...f,score:Math.max(r1.score,r2.score,r3.score),match:r1.match||r2.match||r3.match};
    })
    .filter(f=>f.match)
    .filter(f=>{if(seen.has(f.title)) return false;seen.add(f.title);return true;})
    .sort((a,b)=>b.score-a.score)
    .slice(0,8);
}
function onSearchInput(){
  const q=document.getElementById('ag-search-input').value.trim();
  const res=document.getElementById('ag-search-results');
  if(!q||q.length<2){res.classList.remove('open');return;}
  const films=searchFilms(q);
  if(!films.length){res.innerHTML='<div class="ag-sr-empty">Sin resultados</div>';res.classList.add('open');return;}
  res.innerHTML=films.map(f=>{
    const inWL=watchlist.has(f.title);
    return`<div class="ag-sr-item">
      <div>
        <div class="ag-sr-title">${f.title}</div>
        <div class="ag-sr-meta">${f.flags||''} ${f.duration||''}${f.is_cortos?' · Programa':''}${inWL?' · <span style="color:var(--orange)">♥</span>':''}</div>
      </div>
      <button class="ag-sr-add${inWL?' added':''}" onclick="addFromSearch('${f.title.replace(/'/g,"\'")}')">
        ${inWL?'✓ Añadida':'＋ Añadir'}
      </button>
    </div>`;
  }).join('');
  res.classList.add('open');
}
function addFromSearch(title){
  if(!watchlist.has(title)){watchlist.add(title);watched.delete(title);saveWL();saveWatched();updateCardState(title);updateAgTab();}
  onSearchInput();
  const listEl=document.getElementById('ag-film-list');if(listEl) listEl.innerHTML=renderFilmListHTML();
}

function parseProgramTitle(t){
  let displayTitle=t, progSuffix='';
  const f=FILMS.find(fi=>fi.title===t);
  if(f?.is_cortos){
    if(t.startsWith('Prog.')){
      const m=t.match(/^(Prog\.[^—–]+)\s*[—–]\s*(.+)$/);
      if(m){displayTitle=m[2].trim();progSuffix=m[1].trim();}
    } else {
      const m=t.match(/^(.+?)\s*[—–]\s*(Prog\..*)$/);
      if(m){displayTitle=m[1];progSuffix=m[2];}
    }
    if(progSuffix&&!/\d/.test(progSuffix)) progSuffix='';
  }
  return{displayTitle,progSuffix};
}

function renderPrioStrip(){
  if(!prioritized.size) return'';
  const chips=[...watchlist].filter(t=>prioritized.has(t)).map(t=>{
    const f=FILMS.find(fi=>fi.title===t);
    const p=getPosterSrc(t,f?.is_cortos);
    const img=p?`<img class="prio-chip-poster" src="${p}" loading="lazy" style="${f?.is_cortos?'object-fit:contain;background:#111':''}" onerror="this.outerHTML='<div class=prio-chip-ph>★</div>'" alt="">`:'<div class="prio-chip-ph">★</div>';
    const{displayTitle,progSuffix}=parseProgramTitle(t);
    const short=displayTitle.length>16?displayTitle.slice(0,14)+'…':displayTitle;
    return`<div class="prio-chip">
      ${img}
      <button class="prio-chip-rm" data-prio-title="${t.replace(/"/g,'&quot;')}" onclick="event.stopPropagation();togglePriority(this.dataset.prioTitle)" title="Quitar prioridad">✕</button>
      <div class="prio-chip-title">${short}${progSuffix?`<span style="color:var(--orange);display:block;font-size:8px;margin-top:1px">${progSuffix}</span>`:''}</div>
    </div>`;
  }).join('');
  return`<div class="prio-strip">
    <div class="prio-strip-title">★ Prioridades ${prioritized.size}/${PRIO_LIMIT}</div>
    <div class="prio-strip-row">${chips}</div>
  </div>`;
}
function renderFilmListHTML(){
  const allPending=[...watchlist].filter(t=>!watched.has(t));
  const prioList=allPending.filter(t=>prioritized.has(t));
  const nonPrioList=allPending.filter(t=>!prioritized.has(t));
  const watchedList=[...watched];

  const mkItem=(t)=>{
    const f=FILMS.find(fi=>fi.title===t);
    const hasFuture=FILMS.some(fi=>fi.title===t&&!screeningPassed(fi));
    const FICCI_POSTER_AG='https://ficcifestival.com/sites/default/files/2026-02/logo-ficci65_2.png';
    const posterSrc=f?getPosterSrc(t,f.is_cortos):null;
    const posterHtml=posterSrc?`<img class="ag-fi-poster" src="${posterSrc}" loading="lazy" style="${f?.is_cortos?'object-fit:contain;background:#111':''}" onerror="this.className='ag-fi-poster-ph';this.innerHTML='🎬'" alt="">`:`<div class="ag-fi-poster-ph">🎬</div>`;
    const isPrio=prioritized.has(t);
    const safeT=t.replace(/"/g,'&quot;');
    const{displayTitle,progSuffix}=parseProgramTitle(t);
    return`<div class="ag-film-item${!hasFuture?' watched-item':''}">
      ${posterHtml}
      <div class="ag-fi-overlay"></div>
      <div class="ag-fi-actions">
        <button class="ag-fi-btn prio-fi-btn${isPrio?' prio-on':''}" data-pt="${safeT}" onclick="togglePriority(this.dataset.pt);event.stopPropagation()" title="${isPrio?'Quitar prioridad':'Priorizar'}">★</button>
        <button class="ag-fi-btn w-mark${watched.has(t)?' w-on':''}" data-wt="${safeT}" onclick="toggleWatched(this.dataset.wt,event)" title="Marcar como vista">✓</button>
        <button class="ag-fi-btn del" data-wlt="${safeT}" onclick="toggleWL(this.dataset.wlt,event)" title="Quitar">✕</button>
      </div>
      <div class="ag-fi-bottom">
        <div class="ag-fi-flags">${f?f.flags||'🎬':'🎬'}</div>
        <div class="ag-fi-title">${displayTitle}</div>
        ${progSuffix?`<div style="font-size:9px;color:var(--orange);font-weight:700;margin-top:1px;line-height:1">${progSuffix}</div>`:''}
      </div>
    </div>`;
  };

  let html='';
  if(prioList.length){
    html+=`<div class="prio-strip-title" style="margin-bottom:8px">★ Prioridades ${prioList.length}/${PRIO_LIMIT}</div>`;
    html+=`<div class="ag-film-grid">${prioList.map(t=>mkItem(t)).join('')}</div>`;
  }
  if(nonPrioList.length){
    if(prioList.length) html+=`<div class="ag-list-sep"></div>`;
    html+=`<div class="prio-strip-title" style="margin-bottom:8px">♥︎ Selección ${nonPrioList.length}</div>`;
    html+=`<div class="ag-film-grid">${nonPrioList.map(t=>mkItem(t)).join('')}</div>`;
  }
  if(!allPending.length&&!watchedList.length){
    return`<div style="margin-top:8px;padding:20px 16px;border:1px solid var(--bdr-l);border-radius:var(--r);text-align:center">
      <div class="prio-strip-title" style="justify-content:center;margin-bottom:10px">♥︎ Selección</div>
      <div style="font-size:12px;color:var(--gray);line-height:1.6">
        Aún no tienes películas guardadas.<br>Usa el buscador para añadir títulos.
      </div>
    </div>`;
  }
  if(watchedList.length){
    html+=`<div class="prio-strip-title" style="margin-top:${allPending.length?'10px':'0'};margin-bottom:6px;color:var(--green)">✓ Ya vistas</div>`;
    html+=watchedList.map(t=>{
      const f=FILMS.find(fi=>fi.title===t);
      return`<div class="ag-watched-item">
        <div class="ag-wi-flag">${f?f.flags||'✓':'✓'}</div>
        <div class="ag-wi-title">${t}</div>
        <div class="ag-wi-actions">
          <button class="ag-fi-btn" data-wt="${t.replace(/"/g,'&quot;')}" onclick="toggleWatched(this.dataset.wt,event)" title="Desmarcar">↩</button>
          <button class="ag-fi-btn del" data-wlt="${t.replace(/"/g,'&quot;')}" onclick="toggleWL(this.dataset.wlt,event)" title="Quitar">✕</button>
        </div>
      </div>`;
    }).join('');
  }
  return html||`<div style="margin-top:8px;padding:20px 16px;border:1px solid var(--bdr-l);border-radius:var(--r);text-align:center">
      <div class="prio-strip-title" style="justify-content:center;margin-bottom:10px">♥︎ Selección</div>
      <div style="font-size:12px;color:var(--gray);line-height:1.6">
        Aún no tienes películas guardadas.<br>Usa el buscador para añadir títulos.
      </div>
    </div>`;
}

// ── RENDER SAVED AGENDA ──
// ── Componente unificado: fila de función en agenda ──
// mode='saved'    → ✕ quita de agenda guardada
// mode='scenario' → ✕ quita de watchlist, muestra badge de alternativas
