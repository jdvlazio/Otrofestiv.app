// ── RENDER: Cartelera tab ──
// Film grid render, card building, filter/day logic

function render(){
  if(activeView==='agenda') return;
  renderVbar();renderSbar();
  let films=FILMS.filter(f=>f.day===activeDay);
  if(activeVenue!=='all') films=films.filter(f=>vcfg(f.venue).short===activeVenue);
  if(activeSec!=='all') films=films.filter(f=>f.section===activeSec);
  restoreExpand();
  const cntEl=document.getElementById('cnt');
  if(activeVenue!=='all'||activeSec!=='all'){
    cntEl.innerHTML=`<b>${films.length}</b> función${films.length!==1?'es':''}`;
  } else {
    cntEl.innerHTML='';
  }
  const grid=document.getElementById('grid');
  if(!films.length){grid.innerHTML='<div class="empty"><span>🎞️</span>Sin funciones para este filtro.</div>';return;}
  grid.innerHTML=films.map((f,i)=>{
    const vc=vcfg(f.venue),sl=sala(f.venue);
    const isAp=f.section==='🎬 Apertura',isMid=f.section==='🌙 Medianoche',isProg=f.is_cortos;
    const passed=screeningPassed(f);
    const flags=f.flags||'🎬';
    const tEn=!isProg&&f.title_en&&f.title_en!==f.title&&!f.title_en.includes('·')?f.title_en:'';
    const durMin=f.duration?parseInt(f.duration):0;
    const secActive=activeSec===f.section?' active-sec':'';
    const inWL=watchlist.has(f.title),inW=watched.has(f.title);
    let filmBlock='';
    if(isProg){
      const list=f.film_list||[];
      if(list.length) filmBlock=`<div class="c-film-list">${list.map((item,n)=>{const thumb=SHORT_IMGS[item.title];const thumbHtml=thumb?`<img src="${thumb}" class="c-film-thumb" loading="lazy" onerror="this.style.display='none'" alt="">`:'<div class="c-film-thumb-ph"></div>';return`<div class="c-film-item">${thumbHtml}<div class="c-film-num">${n+1}</div><div class="c-film-info"><div class="c-film-title">${item.title}</div><div class="c-film-meta">${item.country}</div></div><div class="c-film-dur">${item.duration}</div><a class="c-film-lb" href="https://letterboxd.com/search/films/${encodeURIComponent(item.title)}/" target="_blank" rel="noopener" onclick="event.stopPropagation()">${LB_SVG}</a></div>`}).join('')}</div>`;
      else{const titles=(f.title_en||'').split('·').map(t=>t.trim()).filter(Boolean);if(titles.length) filmBlock=`<div class="c-title-pills">${titles.map(t=>`<span class="c-title-pill">${t}</span>`).join('')}</div>`;}
    }
    const expandBtn=isProg&&filmBlock?`<div class="c-expand" onclick="toggleExpand(this,event)"><span>Ver programa</span><span class="c-expand-arrow">▼</span></div>`:'';
    const safe=f.title.replace(/"/g,'&quot;').replace(/'/g,"\'");
    const inPrio=prioritized.has(f.title);
    const prioBtn=`<button class="action-btn prio-btn${inPrio?' prio-on':''}" onclick="togglePriority('${safe}')" title="${inPrio?'Quitar prioridad':'Priorizar'}">★</button>`;
    const actBtns=`<div class="card-actions">
      <button class="action-btn wl-btn${inWL?' wl-on':''}" onclick="toggleWL('${safe}',event)" title="${inWL?'Quitar de Selección':'Añadir a Selección'}">${inWL?'♥':'♡'}</button>
      <button class="action-btn w-btn${inW?' w-on':''}" onclick="toggleWatched('${safe}',event)" title="${inW?'Marcar como pendiente':'Marcar como vista'}">✓</button>
      ${prioBtn}
    </div>`;
    const apBadge=isAp?'<div class="apertura-badge">✦ APERTURA</div>':'';
    const nowBadge=isNowShowing(f)?'<div class="now-label"><span class="now-pulse"></span>AHORA</div>':'';
    const pastBadge=passed?'<div class="past-badge">ya pasó</div>':'';
    const lbPill=isProg?'':`<a class="c-lb" href="https://letterboxd.com/search/films/${encodeURIComponent(f.title)}/" target="_blank" rel="noopener" onclick="event.stopPropagation()">${LB_SVG}<span class="c-lb-text">Letterboxd</span></a>`;
    // Poster: films use getPosterSrc; programs use official FICCI 65 festival poster
    const FICCI_POSTER='https://ficcifestival.com/sites/default/files/2026-02/logo-ficci65_2.png';
    let posterSrc=null, posterHtml='';
    if(!isProg){
      posterSrc=getPosterSrc(f.title,false);
      if(posterSrc) posterHtml=`<div class="c-poster"><img src="${posterSrc}" alt="" loading="lazy" onerror="this.parentElement.innerHTML='<div class=c-poster-none></div>'"></div>`;
    } else {
      posterSrc=true;
      posterHtml=`<div class="c-poster"><img src="${FICCI_POSTER}" alt="FICCI 65" loading="lazy" style="object-fit:contain;background:#111" onerror="this.parentElement.innerHTML='<div class=c-poster-none></div>'"></div>`;
    }
    const hasPoster=!!posterSrc;
    const{displayTitle,progSuffix}=parseProgramTitle(f.title);
    const durLongHtml=durMin>150?`<span class="c-dur-long">⏱ ${Math.floor(durMin/60)}h ${durMin%60}min</span>`:'';
    const zoneHtml=`
      <div class="c-slot-time"><div class="c-time" style="${passed?'color:var(--gray2)':''}">${f.time}</div></div>
      <div class="c-slot-title"><div class="c-title">${displayTitle}${isMid?' 🌙':''}</div></div>
      <div class="c-slot-sub"><div class="c-title-en">${tEn||''}</div></div>
      <div class="c-slot-dur">${durLongHtml}</div>
      <div class="c-slot-flags"><div class="c-flags">${flags}</div></div>
      <div class="c-slot-venue"><div class="c-venue-name">${vc.ico} ${vc.short}${sl?`<span style="color:var(--gray2);margin:0 5px">|</span><span style="color:var(--gray2);font-weight:400">${sl}</span>`:''}</div></div>
      <div class="c-slot-space"></div>`;
    const posterCol=posterHtml
      ?posterHtml
      :`<div class="c-poster empty"><div class="c-poster-none"></div></div>`;
    return`<div class="card${isAp?' apertura':isProg?' program':''}${hasPoster?' has-poster':''}${inWL&&!inW?' in-wl':inW?' in-watched':''}${passed?' past-card':''}" data-idx="${i}" data-title="${f.title.replace(/"/g,'&quot;')}">
      ${pastBadge}${nowBadge}${actBtns}
      <div class="c-body">
        ${posterCol}<div class="c-content">${zoneHtml}</div>
      </div>
      ${filmBlock}
      <div class="c-divider"></div>
      <div class="c-foot">
        <div class="c-foot-left">
          ${apBadge}${isProg&&expandBtn?expandBtn:`<span class="c-sec${secActive}" data-sec="${f.section.replace(/"/g,'&quot;')}">${f.section}</span>`}
          ${lbPill}
        </div>
        <div class="c-foot-space"></div>
        <div class="c-foot-right">
          ${progSuffix?`<span class="c-dur" style="color:var(--gray2)">${progSuffix}</span>`:''}
          <span class="c-dur">🕐 ${f.duration}</span>
        </div>
      </div>
    </div>`;
  }).join('');
  document.querySelectorAll('.card').forEach(card=>{
    card.addEventListener('click',e=>{
      if(e.target.closest('.card-actions')||e.target.closest('.c-expand')||e.target.closest('.c-lb')) return;
      if(e.target.closest('.c-sec')){const sec=e.target.closest('.c-sec').dataset.sec;activeSec=activeSec===sec?'all':sec;selectedIdx=null;setHint(null);render();return;}
      onCardClick(parseInt(card.dataset.idx),films);
    });
  });
  if(selectedIdx!==null&&selectedIdx<films.length) applyStates(films);
}

