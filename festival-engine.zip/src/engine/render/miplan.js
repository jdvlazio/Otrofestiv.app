// ── RENDER: Mi Plan tab ──
// renderMiPlanCalendar, removeFromAgenda, addSuggestion,
// mkAgendaRow, renderSavedAgendaHTML, exportICS, getSuggestions display

function renderMiPlanCalendar(){
  if(!savedAgenda||!savedAgenda.schedule.length) return'';
  const schedule=savedAgenda.schedule;
  const todayStr=new Date().toISOString().slice(0,10);
  const nowDayIdx=DAY_KEYS.findIndex(d=>FESTIVAL_DATES[d]===todayStr);
  const nowMin=new Date().getHours()*60+new Date().getMinutes();
  if(activeMiPlanDay===null){
    const firstDayWithFilm=DAY_KEYS.findIndex(d=>schedule.some(s=>s.day===d));
    activeMiPlanDay=nowDayIdx>=0?nowDayIdx:Math.max(0,firstDayWithFilm);
  }

  // ── Layout constants (Calendly-style generous spacing) ──
  const PHDR=44;   // px for sticky day header
  const PPH=64;    // px per hour
  const SH=9;      // start hour
  const EH=25;     // end hour (1am = 25 to show late-night films)
  const TOTAL=(EH-SH)*PPH;
  function toPx(min){return(min-SH*60)/60*PPH;}

  const dayShort=['MAR','MIÉ','JUE','VIE','SÁB','DOM'];
  const dayNums=[14,15,16,17,18,19];

  // ── Time axis labels (every hour, on the left) ──
  const axisHtml=Array.from({length:EH-SH+1},(_,k)=>{
    const h=SH+k;
    const top=PHDR+toPx(h*60);
    const lbl=(h%24)+':00';
    return`<div class="mplan-wk-htick" style="top:${top.toFixed(0)}px">${lbl}</div>`;
  }).join('');

  // ── 6 day columns ──
  const colsHtml=DAY_KEYS.map((day,i)=>{
    const dayFilms=schedule.filter(s=>s.day===day).sort((a,b)=>toMin(a.time)-toMin(b.time));
    const isPastDay=nowDayIdx>=0&&i<nowDayIdx;
    const isToday=i===nowDayIdx;
    const isActive=i===activeMiPlanDay;

    // Hour grid lines
    let gridHtml='';
    for(let h=SH;h<EH;h++){
      const top=PHDR+toPx(h*60);
      gridHtml+=`<div class="mplan-wk-hline mp-major" style="top:${top.toFixed(0)}px"></div>`;
      gridHtml+=`<div class="mplan-wk-hline" style="top:${(top+PPH/2).toFixed(0)}px"></div>`;
    }

    // Now line
    let nowHtml='';
    if(isToday&&nowMin>=SH*60&&nowMin<EH*60){
      const top=PHDR+toPx(nowMin);
      nowHtml=`<div class="mplan-wk-nowline" style="top:${top.toFixed(0)}px"><div class="mplan-wk-nowdot"></div></div>`;
    }

    // Film blocks
    const blocksHtml=dayFilms.map(s=>{
      const fMin=toMin(s.time),dur=parseDur(s.duration);
      const top=PHDR+toPx(fMin);
      const blockH=Math.max(dur/60*PPH-4,20);
      const isPast=isPastDay||(isToday&&fMin+dur<nowMin);
      const isNow=isToday&&fMin<=nowMin&&fMin+dur>nowMin;
      const type=mplanBlockType(s);
      const stateClass=isPast?' mp-past':isNow?' mp-now':'';
      const{displayTitle}=parseProgramTitle(s._title||'');
      const isPrio=type==='mp-priority';
      const showVenue=blockH>44;
      const vc2=vcfg(s.venue);
      return`<div class="mplan-wk-block ${type}${stateClass}" style="top:${top.toFixed(0)}px;height:${blockH.toFixed(0)}px" onclick="selectMiPlanDay(${i});event.stopPropagation()" title="${(s._title||'').replace(/"/g,'&quot;')}">
        ${isPrio?'<div class="mplan-wk-badge">★</div>':''}
        <div class="mplan-wk-time">${s.time}</div>
        <div class="mplan-wk-title">${displayTitle}</div>
        ${showVenue?`<div class="mplan-wk-venue">${vc2.ico} ${vc2.short}</div>`:''}
      </div>`;
    }).join('');

    const colClass=['mplan-wk-col',isToday?'wk-today':'',isActive?'wk-active':''].filter(Boolean).join(' ');
    return`<div class="${colClass}" style="height:${PHDR+TOTAL}px" onclick="selectMiPlanDay(${i})">
      <div class="mplan-wk-col-hdr">
        <div class="mplan-wk-col-day">${dayShort[i]}</div>
        <div class="mplan-wk-col-date${dayFilms.length?' wk-has':''}">${dayNums[i]}</div>
        ${dayFilms.length?'<div class="mplan-wk-col-dot"></div>':''}
      </div>
      ${gridHtml}${nowHtml}${blocksHtml}
    </div>`;
  }).join('');

  // ── Detail list for active day ──
  const activeKey=DAY_KEYS[activeMiPlanDay];
  const dayFilms=schedule.filter(s=>s.day===activeKey).sort((a,b)=>toMin(a.time)-toMin(b.time));
  const isPastDay=nowDayIdx>=0&&activeMiPlanDay<nowDayIdx;

  let listHtml=`<div class="mplan-list"><div class="mplan-list-hdr">${DAY_LONG[activeKey]||activeKey}</div>`;
  if(!dayFilms.length){
    listHtml+=`<div class="mplan-empty">D\u00eda libre \u2014 sin funciones planificadas</div>`;
  } else {
    dayFilms.forEach((s,idx)=>{
      const fMin=toMin(s.time),dur=parseDur(s.duration);
      const isPast=isPastDay||(activeMiPlanDay===nowDayIdx&&fMin+dur<nowMin);
      const isNow=activeMiPlanDay===nowDayIdx&&fMin<=nowMin&&fMin+dur>nowMin;
      const safeT=(s._title||'').replace(/"/g,'&quot;');
      if(idx>0){
        const prev=dayFilms[idx-1];
        const gap=fMin-(toMin(prev.time)+parseDur(prev.duration));
        if(gap>=0&&gap<25) listHtml+=`<div class="mplan-warn-row">\u25b2 ~${gap} min entre funciones</div>`;
        const tw=travelWarn(prev,s);
        if(tw) listHtml+=`<div class="mplan-warn-row">${tw}</div>`;
      }
      listHtml+=`<div class="mplan-row">
        <div class="mplan-tc">
          <div class="mplan-t1${isPast?' mp-past':''}">${s.time}</div>
          <div class="mplan-t2">${mplanEndStr(s.time,dur)}${isNow?` <span style="color:var(--orange);font-weight:600">en curso</span>`:''}</div>
        </div>
        <div class="mplan-ri">
          <div class="mplan-rtitle">${s._title||''}</div>
          <div class="mplan-rvenue">${vcfg(s.venue).ico} ${vcfg(s.venue).short}${sala(s.venue)?' \u00b7 '+sala(s.venue):''}</div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0">
          <div class="mplan-dur">${s.duration||''}</div>
          <div style="display:flex;gap:4px">
            <button class="ag-fi-btn${watched.has(s._title)?' w-on':''}" data-wt="${safeT}" onclick="toggleWatched(this.dataset.wt,event)" title="${watched.has(s._title)?'Desmarcar':'Marcar como vista'}">${watched.has(s._title)?'\u21a9':'\u2713'}</button>
            <button class="ag-fi-btn del" data-rmt="${safeT}" onclick="removeFromAgenda(this.dataset.rmt);event.stopPropagation()" title="Quitar">\u2715</button>
          </div>
        </div>
      </div>`;
    });
  }
  listHtml+='</div>';

  return`<div class="mplan-wrap">
    <div class="mplan-wk-outer">
      <div class="mplan-wk-inner" style="height:${PHDR+TOTAL}px">
        <div class="mplan-wk-axis" style="height:${PHDR+TOTAL}px">${axisHtml}</div>
        <div class="mplan-wk-cols">${colsHtml}</div>
      </div>
    </div>
    ${listHtml}
  </div>`;
}



function removeFromAgenda(title){
  if(!savedAgenda) return;
  if(!confirm(`Quitar "${title.length>40?title.slice(0,38)+'…':title}" de tu Plan?`)) return;
  // Guardar el slot exacto antes de borrar
  const removed=savedAgenda.schedule.find(s=>s._title===title);
  if(removed){
    lastRemovedSlots=lastRemovedSlots.filter(r=>r._title!==removed._title);
    lastRemovedSlots.unshift({...removed,_isRestored:true});
    if(lastRemovedSlots.length>MAX_REMEMBERED_SLOTS) lastRemovedSlots.length=MAX_REMEMBERED_SLOTS;
    saveLastSlot();
  }
  savedAgenda.schedule=savedAgenda.schedule.filter(s=>s._title!==title);
  if(!savedAgenda.schedule.length) savedAgenda=null;
  saveSavedAgenda();
  renderAgenda();
  showToast('Quitada de Mi Plan','info');
}
function addSuggestion(title,day,time){
  // 1. Add to watchlist if not already there
  if(!watchlist.has(title)){watchlist.add(title);watched.delete(title);saveWL();saveWatched();updateCardState(title);updateAgTab();}
  // 2. Add specific screening to saved agenda
  const screen=FILMS.find(f=>f.title===title&&f.day===day&&f.time===time);
  if(screen){
    if(!savedAgenda) savedAgenda={schedule:[]};
    // Avoid duplicates
    if(!savedAgenda.schedule.some(s=>s._title===title)){
      // No se re-valida conflicto aquí: getSuggestions ya garantizó que la función
      // cabe en el hueco (los slots ya incluyen el buffer ±10). screensConflict
      // añadiría ±10 adicional sobre ambos lados → falso positivo sistemático
      // en funciones que empiezan exactamente en el borde del slot.
      savedAgenda.schedule.push({...screen,_title:title});
      savedAgenda.schedule.sort((a,b)=>a.day_order!==b.day_order?a.day_order-b.day_order:toMin(a.time)-toMin(b.time));
      saveSavedAgenda();
    }
  }
  // 3. Quitar de lista de restaurables
  lastRemovedSlots=lastRemovedSlots.filter(r=>r._title!==title);
  saveLastSlot();
  // 4. Saltar al día de la sugerencia en el calendario
  const jumpIdx=DAY_KEYS.indexOf(day);
  if(jumpIdx>=0) activeMiPlanDay=jumpIdx;
  // 5. Re-render
  renderAgenda();
}
function closeSearch(){setTimeout(()=>{const r=document.getElementById('ag-search-results');if(r) r.classList.remove('open');},200);}

// ── AVAILABILITY ──
// ─────────────────────────────────────────────────────────────────────────────
// ⚠️  FIX CRÍTICO — NO REMOVER (Apr 2026)
// DAY_KEYS debe estar declarada aquí, antes de cualquier función que la use.
// Sin esta declaración, Planear lanza "Can't find variable: DAY_KEYS" y
// la pestaña entera no renderiza.

function mkAgendaRow(s, mode='saved'){
  const t=s._title||'';
  const f=FILMS.find(fi=>fi.title===t);
  const _p=getPosterSrc(t,f?.is_cortos);
  const _ph=_p?`<img class="lb-poster" src="${_p}" loading="lazy" onerror="this.outerHTML='<div class=lb-poster-ph>🎬</div>'" alt="">`:'<div class="lb-poster-ph">🎬</div>';
  const vc2=vcfg(s.venue),sl=sala(s.venue);
  const safeT=(s._title||'').replace(/"/g,'&quot;');
  const isDone=watched.has(t);
  const alts=mode==='scenario'?FILMS.filter(fi=>fi.title===t&&!isScreeningBlocked(fi)&&!screeningPassed(fi)&&!(fi.day===s.day&&fi.time===s.time)):[];
  const altBadge=alts.length?`<span class="ag-alts">${alts.length} alt.</span>`:'';
  const actionBtn=mode==='saved'
    ?`<button class="ag-fi-btn del" data-rmt="${safeT}" onclick="removeFromAgenda(this.dataset.rmt);event.stopPropagation()" title="Quitar de agenda">✕</button>`
    :`<button class="ag-fi-btn del" data-wlt="${safeT}" onclick="toggleWL(this.dataset.wlt,event)" title="Quitar">✕</button>`;
  return`<div class="saved-item${isDone?' done':''}">
    ${_ph}
    <div class="saved-time">${s.time}</div>
    <div class="saved-info">
      <div class="saved-title">${t}</div>
      <div class="saved-venue">${vc2.ico} ${vc2.short}${sl?' · '+sl:''}${s.duration?' · '+s.duration:''}${altBadge}</div>
    </div>
    <button class="saved-check${isDone?' done':''}" data-wt="${safeT}" onclick="toggleWatched(this.dataset.wt,event)" title="${isDone?'Desmarcar':'Marcar como vista'}">${isDone?'↩':'✓'}</button>
    ${actionBtn}
  </div>`;
}

function renderSavedAgendaHTML(){
  // ⚠️ FIX CRÍTICO — NO REMOVER (Apr 2026)
  // try/catch permanente: un error en renderMiPlanCalendar u otras subfunciones
  // causaba que Mi Agenda quedara en blanco sin ningún mensaje de error visible.
  // Este wrapper aísla el fallo y muestra el error en pantalla en lugar de silencio.
  try{ return _renderSavedAgendaHTML(); }
  catch(err){
    console.error('renderSavedAgendaHTML error:',err);
    return`<div style="margin:16px;padding:16px;border:1px solid #e05050;border-radius:var(--r);font-size:12px;color:#e05050">
      <strong>Error al cargar Mi Plan:</strong><br>
      <code style="font-size:10px;opacity:.8">${err.message}</code>
    </div>`;
  }
}
function _renderSavedAgendaHTML(){
  if(!savedAgenda||!savedAgenda.schedule.length) return`
    <div style="margin-top:16px;padding:20px 16px;border:1px solid var(--bdr-l);border-radius:var(--r);text-align:center">
      <div class="prio-strip-title" style="justify-content:center;margin-bottom:10px">◆ Mi Plan</div>
      <div style="font-size:12px;color:var(--gray);line-height:1.6;margin-bottom:14px">
        Aún no tienes un plan guardado.<br>Ve a <strong style="color:var(--white)">Planear</strong>, calcula un escenario y toca <strong style="color:var(--white)">◆ Elegir Plan</strong>.
      </div>
      <button onclick="switchMainNav('mnav-planner');showAgView()" style="background:none;border:1px solid var(--bdr);border-radius:20px;color:var(--gray);font-size:11px;padding:5px 14px;cursor:pointer;font-family:'DM Sans',sans-serif;transition:all .15s" onmouseover="this.style.borderColor='var(--orange)';this.style.color='var(--orange)'" onmouseout="this.style.borderColor='var(--bdr)';this.style.color='var(--gray)'">Ir a Planear →</button>
    </div>`;
  const all=savedAgenda.schedule;
  const archive=all.filter(s=>screeningPassed(s)||watched.has(s._title));
  const upcoming=all.filter(s=>!screeningPassed(s)&&!watched.has(s._title));
  const todayItems=upcoming.filter(s=>isToday(s.day));
  const futureItems=upcoming.filter(s=>!isToday(s.day));
  const byDay={};
  futureItems.forEach(s=>{if(!byDay[s.day])byDay[s.day]=[];byDay[s.day].push(s);});

  const festDays=['Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];
  const today=new Date().toISOString().slice(0,10);
  const dayIdx=festDays.findIndex(d=>FESTIVAL_DATES[d]===today);
  const currentDayNum=dayIdx>=0?dayIdx+1:null;
  const viewedCount=[...watched].length;
  const progressPct=dayIdx>=0?Math.round((dayIdx/5)*100):0;
  const progressBar=currentDayNum?`<div class="festival-progress">
    <div class="festival-progress-text"><span>Día <b>${currentDayNum}</b> de 6</span><span style="color:var(--orange)">✓ ${viewedCount} ${viewedCount===1?'vista':'vistas'}</span></div>
    <div class="festival-progress-bar"><div class="festival-progress-fill" style="width:${progressPct}%"></div></div>
  </div>`:'';

  let html=`<div class="saved-agenda">
    ${progressBar}
    <div class="saved-agenda-header">
      <div class="prio-strip-title" style="margin-bottom:0">◆ Mi Plan</div>
      <div style="display:flex;gap:6px">
        <button class="saved-agenda-clear" onclick="exportICS()" style="color:var(--orange)">📅 .ics</button>
        <button class="saved-agenda-clear" onclick="clearSavedAgenda()">✕ Borrar</button>
      </div>
    </div>`;

  if(archive.length){
    const archByDay={};
    archive.forEach(s=>{if(!archByDay[s.day])archByDay[s.day]=[];archByDay[s.day].push(s);});
    html+=`<div class="archive-toggle" onclick="toggleArchive()">
      <span class="archive-toggle-lbl">▾ Historial (${archive.length}) — toca para ver</span>
      <span id="arch-arrow" style="color:var(--gray);font-size:11px">▼</span>
    </div>
    <div class="archive-body" id="archive-body">
      ${DAY_KEYS.filter(d=>archByDay[d]).map(day=>`
        <div class="saved-day-lbl">${DAY_SHORT[day]}</div>
        ${archByDay[day].map(s=>{
          const vc2=vcfg(s.venue),sl=sala(s.venue);
          return`<div class="saved-item done">
            <div class="saved-time">${s.time}</div>
            <div class="saved-info">
              <div class="saved-title">${s._title}</div>
              <div class="saved-venue">${vc2.ico} ${vc2.short}${sl?' · '+sl:''}</div>
            </div>
            <button class="saved-check done" data-wt="${(s._title||'').replace(/"/g,'&quot;')}" onclick="toggleWatched(this.dataset.wt,event)" title="Desmarcar">↩</button>
          </div>`;
        }).join('')}`).join('')}
    </div>`;
  }

  if(todayItems.length){
    html+=`<div class="today-banner">Hoy — Funciones pendientes</div>`;
  }

  html+=renderMiPlanCalendar();

  const suggsByDay=getSuggestions();
  const suggDays=DAY_KEYS.filter(d=>suggsByDay[d]&&suggsByDay[d].length>0);
  if(suggDays.length){
    html+=`<div class="suggestion-wrap">
      <div class="prio-strip-title" style="margin-bottom:8px">◇ Sugerencias</div>`;
    suggDays.forEach(day=>{
      html+=`<div class="suggestion-day-lbl">${day}</div>`;
      html+=suggsByDay[day].slice(0,4).map(f=>{
        const vc2=vcfg(f.venue),sl=sala(f.venue);
        const _sp=getPosterSrc(f.title,false);
        const _sph=_sp?`<img class="lb-poster" src="${_sp}" loading="lazy" onerror="this.outerHTML='<div class=lb-poster-ph>🎬</div>'" alt="">`:'<div class="lb-poster-ph">🎬</div>';
        return`<div class="suggestion-item">
          ${_sph}
          <div class="suggestion-time">${f.time}</div>
          <div class="suggestion-info">
            <div class="suggestion-title">${f.title}</div>
            <div class="suggestion-meta">${f.flags||''} ${f.section||''} · ${vc2.ico} ${vc2.short}${sl?' · '+sl:''} · ${f.duration}</div>
            ${f.gapCtx?`<div style="font-size:9px;color:var(--gray);margin-top:2px;font-style:italic">${f.gapCtx}</div>`:''}
          </div>
          <button class="suggestion-add" onclick="addSuggestion('${f.title.replace(/'/g,"\\'")}','${f.day}','${f.time}')" style="${f._isRestored?'border-color:var(--orange);color:var(--orange);background:rgba(232,90,30,.1)':''}">
            ${f._isRestored?'← Restaurar':'＋ Añadir'}
          </button>
        </div>`;
      }).join('');
    });
    html+='</div>'; // close suggestion-wrap
  }

  html+='</div>';
  return html;
}
let archiveOpen=false;
function toggleArchive(){
  archiveOpen=!archiveOpen;
  const body=document.getElementById('archive-body');
  const arrow=document.getElementById('arch-arrow');
  if(body) body.classList.toggle('open',archiveOpen);
  if(arrow) arrow.textContent=archiveOpen?'▲':'▼';
}


function exportICS(){
  if(!savedAgenda||!savedAgenda.schedule.length){showToast('No tienes un Plan guardado','warn');return;}
  const pad=n=>String(n).padStart(2,'0');
  const fmt=dt=>`${dt.getFullYear()}${pad(dt.getMonth()+1)}${pad(dt.getDate())}T${pad(dt.getHours())}${pad(dt.getMinutes())}00`;
  const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//FICCI65//ES','CALSCALE:GREGORIAN','METHOD:PUBLISH'];
  savedAgenda.schedule.forEach(s=>{
    const dateStr=FESTIVAL_DATES[s.day];if(!dateStr) return;
    const start=new Date(`${dateStr}T${s.time}:00`);
    const dur=s.duration?parseInt(s.duration):90;
    const end=new Date(start.getTime()+dur*60000);
    const vc=VENUES[s.venue]||{};
    lines.push('BEGIN:VEVENT',
      `DTSTART:${fmt(start)}`,`DTEND:${fmt(end)}`,
      `SUMMARY:${s._title}`,
      `LOCATION:${s.venue}`,
      `DESCRIPTION:FICCI 65 · ${s.section||''} · ${s.duration||''}`,
      'END:VEVENT');
  });
  lines.push('END:VCALENDAR');
  const blob=new Blob([lines.join('\r\n')],{type:'text/calendar'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='FICCI65_agenda.ics';a.click();
  showToast('📅 Calendario exportado','info');
}
function clearSavedAgenda(){savedAgenda=null;localStorage.removeItem('ficci65_saved');renderAgenda();}

