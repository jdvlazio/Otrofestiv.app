// ── RENDER: Planear tab ──
// Availability blocks, renderAvDay, isScreeningBlocked, buildResultHTML, runCalc

// ─────────────────────────────────────────────────────────────────────────────
const DAY_KEYS=['Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];
const DAY_LONG={Martes:'Martes 14',Miércoles:'Miércoles 15',Jueves:'Jueves 16',Viernes:'Viernes 17',Sábado:'Sábado 18',Domingo:'Domingo 19'};
const DAY_SHORT={Martes:'MAR 14',Miércoles:'MIÉ 15',Jueves:'JUE 16',Viernes:'VIE 17',Sábado:'SÁB 18',Domingo:'DOM 19'};
let avAddOpen={};
function isFullDayBlocked(day){return availability[day].blocks.some(b=>toMin(b.from)<=0&&toMin(b.to)>=toMin('23:59'));}
function toggleFullDay(day){
  if(isFullDayBlocked(day)) availability[day].blocks=[];
  else{availability[day].blocks=[{from:'00:00',to:'23:59'}];avAddOpen[day]=false;}
  cachedResult=null;saveAV();renderAvDay(day);invalidateCalcResult();
}
function addBlock(day){
  const f=document.getElementById(`av-from-${day}`).value;
  const t=document.getElementById(`av-to-${day}`).value;
  if(!f||!t){showToast('Selecciona hora de inicio y fin','warn');return;}
  if(toMin(f)>=toMin(t)){showToast('La hora de inicio debe ser menor que la de fin','warn');return;}
  const av=availability[day];
  if(av.blocks.some(b=>toMin(f)<toMin(b.to)&&toMin(t)>toMin(b.from))){showToast('Este horario se solapa con uno existente','warn');return;}
  av.blocks.push({from:f,to:t});av.blocks.sort((a,b)=>toMin(a.from)-toMin(b.from));
  avAddOpen[day]=false;
  cachedResult=null;saveAV();renderAvDay(day);invalidateCalcResult();
}
function removeBlock(day,fromVal,toVal){
  availability[day].blocks=availability[day].blocks.filter(b=>!(b.from===fromVal&&b.to===toVal));
  cachedResult=null;saveAV();renderAvDay(day);invalidateCalcResult();
}
function renderAvDay(day){
  const row=document.getElementById(`av-row-${day}`);if(!row) return;
  const fullBlocked=isFullDayBlocked(day);
  const visibleBlocks=availability[day].blocks.filter(b=>!(toMin(b.from)<=0&&toMin(b.to)>=toMin('23:59')));
  const hasAny=fullBlocked||visibleBlocks.length>0;
  const addOpen=!!avAddOpen[day];

  const pillsHtml=fullBlocked
    ?`<span class="av-pill full">Todo el día</span>`
    :visibleBlocks.map(b=>`<span class="av-pill">${b.from}–${b.to}<button class="av-pill-rm" onclick="removeBlock('${day}','${b.from}','${b.to}');event.stopPropagation()">×</button></span>`).join('');

  // Inline form — always shows when addOpen, with 15-min slot dropdowns
  const timeOpts=`<option value="08:00">08:00</option><option value="08:15">08:15</option><option value="08:30">08:30</option><option value="08:45">08:45</option><option value="09:00">09:00</option><option value="09:15">09:15</option><option value="09:30">09:30</option><option value="09:45">09:45</option><option value="10:00">10:00</option><option value="10:15">10:15</option><option value="10:30">10:30</option><option value="10:45">10:45</option><option value="11:00">11:00</option><option value="11:15">11:15</option><option value="11:30">11:30</option><option value="11:45">11:45</option><option value="12:00">12:00</option><option value="12:15">12:15</option><option value="12:30">12:30</option><option value="12:45">12:45</option><option value="13:00">13:00</option><option value="13:15">13:15</option><option value="13:30">13:30</option><option value="13:45">13:45</option><option value="14:00">14:00</option><option value="14:15">14:15</option><option value="14:30">14:30</option><option value="14:45">14:45</option><option value="15:00">15:00</option><option value="15:15">15:15</option><option value="15:30">15:30</option><option value="15:45">15:45</option><option value="16:00">16:00</option><option value="16:15">16:15</option><option value="16:30">16:30</option><option value="16:45">16:45</option><option value="17:00">17:00</option><option value="17:15">17:15</option><option value="17:30">17:30</option><option value="17:45">17:45</option><option value="18:00">18:00</option><option value="18:15">18:15</option><option value="18:30">18:30</option><option value="18:45">18:45</option><option value="19:00">19:00</option><option value="19:15">19:15</option><option value="19:30">19:30</option><option value="19:45">19:45</option><option value="20:00">20:00</option><option value="20:15">20:15</option><option value="20:30">20:30</option><option value="20:45">20:45</option><option value="21:00">21:00</option><option value="21:15">21:15</option><option value="21:30">21:30</option><option value="21:45">21:45</option><option value="22:00">22:00</option><option value="22:15">22:15</option><option value="22:30">22:30</option><option value="22:45">22:45</option><option value="23:00">23:00</option><option value="23:15">23:15</option><option value="23:30">23:30</option><option value="23:45">23:45</option><option value="00:00">00:00</option><option value="00:15">00:15</option><option value="00:30">00:30</option><option value="00:45">00:45</option><option value="00:00">01:00</option>`;
  const inlineForm=addOpen?`<div class="av-inline-form">
      <select id="av-from-${day}" class="av-time-input">${timeOpts}</select>
      <span class="av-sep">–</span>
      <select id="av-to-${day}" class="av-time-input">${timeOpts}</select>
      <button class="av-add-btn" onclick="addBlock('${day}')">Confirmar</button>
      <button class="av-plus-btn" onclick="avAddOpen['${day}']=false;renderAvDay('${day}')">✕</button>
    </div>`:'';

  row.className=`av-row${fullBlocked?' av-full':''}`;
  row.innerHTML=`
    <div class="av-row-lbl">
      <div class="av-row-dayname">${DAY_SHORT[day]}</div>
      <div class="av-row-date${hasAny?' wk-has':''}">${FESTIVAL_DATES[day].slice(-2)}</div>
    </div>
    <div class="av-row-content">
      ${pillsHtml?`<div class="av-pills">${pillsHtml}</div>`:''}
      ${inlineForm}
      <div class="av-row-btns" style="margin-top:${pillsHtml||addOpen?'6px':'0'}">
        ${!fullBlocked&&!addOpen?`<button class="av-plus-btn" onclick="avAddOpen['${day}']=true;renderAvDay('${day}')">＋ No disponible</button>`:''}
        ${!addOpen?`<button class="av-full-btn${fullBlocked?' active':''}" onclick="toggleFullDay('${day}')">
          ${fullBlocked?'↩ Liberar día':'Todo el día'}
        </button>`:''}
      </div>
    </div>`;
  // Set default values for selects after render
  if(addOpen){
    const sf=document.getElementById(`av-from-${day}`);
    const st=document.getElementById(`av-to-${day}`);
    if(sf) sf.value='12:00';
    if(st) st.value='14:00';
  }
}

// ── RESULT HTML ──
let cachedResult=null;

function buildResultHTML(scenarios){
  if(!scenarios||!scenarios.length)
    return`<div class="ag-calc-prompt">No hay combinaciones posibles. Ajusta disponibilidad o añade más películas.</div>`;
  const{currentIdx}=cachedResult;
  const sc=scenarios[currentIdx],n=scenarios.length;
  const pending=[...watchlist].filter(t=>!watched.has(t)&&FILMS.some(f=>f.title===t&&!screeningPassed(f)));
  const total=pending.length,ok=sc.schedule.length,bad=sc.excluded.length;
  const isOptimo=currentIdx===0;

  // ── Header: Plan óptimo vs Variación ──
  const planLabel=isOptimo?'◆ Plan óptimo':`Variación ${currentIdx}`;

  // ── Navigation ──
  let navHtml='';
  if(n>1){
    const prevLabel=currentIdx<=1?'◆ Plan óptimo':`Variación ${currentIdx-1}`;
    const nextLabel=currentIdx===0?'Variación 1':`Variación ${currentIdx+1}`;
    navHtml=`<div class="ag-nav" style="margin-top:8px">
      <button class="ag-nav-btn" onclick="changeScenario(-1)" ${currentIdx===0?'disabled':''}>‹ ${prevLabel}</button>
      <button class="ag-nav-btn" onclick="changeScenario(1)" ${currentIdx===n-1?'disabled':''}>${nextLabel} ›</button>
    </div>`;
  }

  let html=`<div class="ag-summary">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
      <div>
        <div class="ag-summary-title" style="font-size:${isOptimo?'15px':'13px'};color:${isOptimo?'var(--white)':'var(--gray)'}">${planLabel}</div>
        <div class="ag-summary-text" style="margin-top:3px">
          <span class="ok"><b>${ok}</b></span> de <b>${total}</b> películas
          ${bad?`<span class="conflict-label"> · <b>${bad}</b> con ajustes</span>`:''}
        </div>
        ${sc.incompatiblePriorities?`<div style="margin-top:5px;font-size:11px;color:#e05050">Las prioridades se solapan entre sí — plan calculado sin forzarlas.</div>`:''}
      </div>
      <button class="ag-save-btn" onclick="saveCurrentScenario()" style="flex-shrink:0">◆ Elegir Plan</button>
    </div>
    ${navHtml}
  </div>`;

  // ── Film list by day ──
  const byDay={};
  sc.schedule.forEach(s=>{if(!byDay[s.day])byDay[s.day]=[];byDay[s.day].push(s);});
  DAY_KEYS.forEach(day=>{
    const films=byDay[day];if(!films||!films.length) return;
    html+=`<div class="ag-day-label"><span>${DAY_SHORT[day]}</span>${films.length} película${films.length!==1?'s':''}</div>`;
    films.forEach((s,i)=>{
      if(i>0){const warn=travelWarn(films[i-1],s);if(warn) html+=`<div class="ag-warn">${warn}</div>`;}
      html+=mkAgendaRow(s,'scenario');
    });
  });

  // ── Con ajustes ──
  if(sc.excluded.length){
    html+=`<div class="ag-conflicts">
      <div class="ag-conflicts-title" style="color:var(--gray);font-size:10px;letter-spacing:.8px">CON AJUSTES · ${sc.excluded.length} película${sc.excluded.length!==1?'s':''}</div>
      ${sc.excluded.map(t=>{
        const screens=FILMS.filter(f=>f.title===t&&!isScreeningBlocked(f)&&!screeningPassed(f));
        const swapOptions=screens.map(s=>{
          const displaced=sc.schedule.filter(chosen=>screensConflict(chosen,s)).map(c=>c._title);
          return{screen:s,displaced};
        }).filter(o=>o.displaced.length>=1&&o.displaced.length<=2);
        let fitsHtml='';
        if(swapOptions.length){
          fitsHtml=`<div style="margin-top:5px;font-size:10px">
            <span style="color:var(--gray2);display:block;margin-bottom:3px">Incluirla desplaza:</span>
            <div style="display:flex;flex-wrap:wrap;gap:4px">
              ${swapOptions.map(o=>o.displaced.map(d=>`<button data-ex="${encodeURIComponent(t)}" data-day="${o.screen.day}" data-time="${o.screen.time}" data-dis="${encodeURIComponent(d)}" onclick="swapFilm(decodeURIComponent(this.dataset.ex),this.dataset.day,this.dataset.time,decodeURIComponent(this.dataset.dis));event.stopPropagation()" style="background:rgba(232,90,30,.1);border:1px solid rgba(232,90,30,.3);color:var(--orange);font-size:10px;padding:3px 8px;border-radius:5px;cursor:pointer;line-height:1.3">⇄ ${d.length>20?d.slice(0,18)+'…':d}</button>`).join('')).join('')}
            </div>
          </div>`;
        } else if(screens.length){
          fitsHtml=`<div style="margin-top:3px;font-size:10px;color:var(--gray2)">Solapa con todas las funciones de este plan</div>`;
        } else {
          fitsHtml=`<div style="margin-top:3px;font-size:10px;color:var(--gray2)">Sin funciones futuras disponibles</div>`;
        }
        const isPrio=prioritized.has(t);
        const atLimit=!isPrio&&prioritized.size>=PRIO_LIMIT;
        const prioLabel=isPrio?'✕ Sin prioridad':atLimit?`★ ${PRIO_LIMIT}/${PRIO_LIMIT}`:'⭐ Priorizar';
        const prioAction=isPrio?`togglePriority('${t.replace(/'/g,"\\'")}')`:atLimit?`showToast('Máximo ${PRIO_LIMIT} prioridades activas','warn')`:`togglePriority('${t.replace(/'/g,"\\'")}')`;
        const _ic2=FILMS.find(f=>f.title===t)?.is_cortos;
        const _ep=getPosterSrc(t,_ic2);
        const _eph=_ep?`<img class="lb-poster" src="${_ep}" loading="lazy" onerror="this.outerHTML='<div class=lb-poster-ph>🎬</div>'" alt="">`:'<div class="lb-poster-ph">🎬</div>';
        return`<div class="ag-conflict-item">
          ${_eph}
          <div class="ag-conflict-info">
            ${isPrio?'<span style="color:var(--orange);font-size:10px;font-weight:700">★ PRIORIDAD · </span>':''}
            <strong>${(()=>{const{displayTitle,progSuffix}=parseProgramTitle(t);return displayTitle+(progSuffix?` <span style="color:var(--orange);font-size:10px;font-weight:700">${progSuffix}</span>`:'');})()}</strong>
            ${fitsHtml}
          </div>
          <button class="ag-prioritize-btn${isPrio?' active':''}${atLimit?' disabled':''}" onclick="${prioAction}">
            ${prioLabel}
          </button>
        </div>`;
      }).join('')}
    </div>`;
  }

  return html;
}

function togglePriority(title,cost){
  if(prioritized.has(title)){
    // Si estamos en Planear, confirmar antes de quitar
    if(activeMNav==='mnav-planner'){
      const short=title.length>40?title.slice(0,38)+'…':title;
      if(!confirm(`¿Quitar "★ ${short}" de tus prioridades?\n\nPodrás cambiarla en Selección.`)) return;
    }
    prioritized.delete(title);
    savePrio();updateCardState(title);updateAgTab();runCalc();
    showToast('Prioridad eliminada','info');
  } else {
    if(prioritized.size>=PRIO_LIMIT){
      showToast(`Máximo ${PRIO_LIMIT} prioridades activas. Quita una para cambiar.`,'warn');return;
    }
    prioritized.add(title);
    savePrio();updateCardState(title);updateAgTab();
    showToast(`★ Prioridad activada · ${prioritized.size}/${PRIO_LIMIT}`,'info');
    runCalc();
  }
  if(activeView==='agenda') renderAgenda();
}
function showToast(msg,type='info'){
  let t=document.getElementById('prio-toast');
  if(!t){t=document.createElement('div');t.id='prio-toast';document.body.appendChild(t);}
  t.className='prio-toast '+type;t.textContent=msg;t.style.opacity='1';
  clearTimeout(t._to);t._to=setTimeout(()=>{t.style.opacity='0';},3000);
}
function swapFilm(excludedTitle, screenDay, screenTime, displacedTitle){
  if(!cachedResult) return;
  const sc=cachedResult.scenarios[cachedResult.currentIdx];
  const newScreen=FILMS.find(f=>f.title===excludedTitle&&f.day===screenDay&&f.time===screenTime);
  if(!newScreen) return;

  // Build the resulting schedule after the swap
  const newSchedule=[...sc.schedule.filter(s=>s._title!==displacedTitle),{...newScreen,_title:excludedTitle}];
  newSchedule.sort((a,b)=>a.day_order!==b.day_order?a.day_order-b.day_order:toMin(a.time)-toMin(b.time));
  const newKey=newSchedule.map(s=>s._title+'@'+s.day+s.time).sort().join('|');

  // Check if this exact schedule already exists in one of the calculated scenarios
  const existingIdx=cachedResult.scenarios.findIndex(s=>{
    const k=s.schedule.map(x=>x._title+'@'+x.day+x.time).sort().join('|');
    return k===newKey;
  });

  if(existingIdx>=0){
    // Jump to the existing scenario
    cachedResult.currentIdx=existingIdx;
    const lbl=existingIdx===0?'◆ Plan óptimo':`Variación ${existingIdx}`;
    showToast(`${lbl} — ya tenías esta combinación`,'info');
  } else {
    // Create a new custom scenario
    const pending=[...watchlist].filter(t=>!watched.has(t)&&FILMS.some(f=>f.title===t&&!screeningPassed(f)));
    const included=new Set(newSchedule.map(s=>s._title));
    cachedResult.scenarios.push({
      ...sc,
      schedule:newSchedule,
      excluded:pending.filter(t=>!included.has(t))
    });
    cachedResult.currentIdx=cachedResult.scenarios.length-1;
    showToast(`Variación ${cachedResult.currentIdx} — intercambio personalizado`,'info');
  }

  const res=document.getElementById('ag-result');
  if(res) res.innerHTML=buildResultHTML(cachedResult.scenarios);
}
function saveCurrentScenario(){
  if(!cachedResult||!cachedResult.scenarios.length) return;
  savedAgenda={schedule:[...cachedResult.scenarios[cachedResult.currentIdx].schedule]};
  saveSavedAgenda();
  // Saltar a Mi Plan — un solo render
  switchMainNav('mnav-miplan');
  showAgView(); // showAgView llama renderAgenda(), no llamar de nuevo
  const agView=document.getElementById('ag-view');
  if(agView) agView.scrollTop=0;
  showToast('◆ Plan elegido — lo ves en Mi Plan','info');
}
function invalidateCalcResult(){
  // Called when availability changes — resets result prompt
  if(!document.getElementById('ag-result')) return;
  const res=document.getElementById('ag-result');
  const pending=[...watchlist].filter(t=>!watched.has(t)&&FILMS.some(f=>f.title===t&&!screeningPassed(f)));
  res.innerHTML=pending.length
    ?`<div class="ag-calc-prompt">Configura tu disponibilidad y toca <strong>Calcular Escenarios</strong>.</div>`
    :`<div class="ag-calc-prompt">Añade películas en <strong>Selección</strong> para poder calcular escenarios.</div>`;
}
function runCalc(){
  cachedResult=null;
  const btn=document.querySelector('.av-calc-btn');
  const res=document.getElementById('ag-result');
  // ── Loading state: mostrar siempre aunque el resultado sea idéntico ──
  if(btn){btn.disabled=true;btn.textContent='Calculando…';}
  if(res) res.innerHTML=`<div class="ag-calc-prompt" style="opacity:.6">◌ Calculando escenarios…</div>`;
  // Defer computation to allow browser to paint loading state first
  setTimeout(()=>{
    try{
      const scenarios=computeScenarios([...watchlist]);
      cachedResult={scenarios,currentIdx:0};
      if(res) res.innerHTML=buildResultHTML(scenarios);
    }catch(err){
      if(res) res.innerHTML=`<div class="ag-calc-prompt" style="color:#e05050"><strong>Error al calcular:</strong><br><code style="font-size:10px">${err.message}</code></div>`;
      console.error('runCalc error:',err);
    }finally{
      if(btn){btn.disabled=false;btn.textContent='Calcular Escenarios';}
    }
  },80);
}
function changeScenario(dir){
  if(!cachedResult) return;
  const n=cachedResult.scenarios.length;
  cachedResult.currentIdx=Math.max(0,Math.min(n-1,cachedResult.currentIdx+dir));
  const res=document.getElementById('ag-result');
  if(res) res.innerHTML=buildResultHTML(cachedResult.scenarios);
}

function updatePrioCounter(){
  const el=document.getElementById('prio-counter');
  if(!el) return;
  el.textContent=prioritized.size>0?`⭐ ${prioritized.size}/${PRIO_LIMIT}`:'';
}
function renderAgenda(){
  const view=document.getElementById('ag-view');
  if(activeMNav==='mnav-seleccion'){
    // ── Selección: buscador + lista de películas ──
    view.innerHTML=`
      <div class="ag-section">
        <div class="ag-search-wrap">
          <span class="ag-search-ico">🔍</span>
          <input type="text" id="ag-search-input" class="ag-search"
            placeholder="Buscar y añadir película o programa…"
            oninput="onSearchInput()" onblur="closeSearch()" autocomplete="off">
          <div id="ag-search-results" class="ag-search-results"></div>
        </div>
        <div id="ag-film-list">${renderFilmListHTML()}</div>
      </div>`;
  } else if(activeMNav==='mnav-miplan'){
    // ── Mi Plan: calendario + sugerencias ──
    view.innerHTML=renderSavedAgendaHTML();
  } else {
    // ── Planear: prio strip compacto + disponibilidad + escenarios ──
    const pending=[...watchlist].filter(t=>!watched.has(t)&&FILMS.some(f=>f.title===t&&!screeningPassed(f)));
    const resultContent=cachedResult
      ?buildResultHTML(cachedResult.scenarios)
      :pending.length
        ?`<div class="ag-calc-prompt">Configura tu disponibilidad y toca <strong>Calcular Escenarios</strong>.</div>`
        :`<div class="ag-calc-prompt">Añade películas en <strong>Selección</strong> para poder calcular escenarios.</div>`;
    view.innerHTML=`
      <div class="ag-section">
        <div class="ag-search-wrap">
          <span class="ag-search-ico">🔍</span>
          <input type="text" id="ag-search-input" class="ag-search"
            placeholder="Buscar y añadir película o programa…"
            oninput="onSearchInput()" onblur="closeSearch()" autocomplete="off">
          <div id="ag-search-results" class="ag-search-results"></div>
        </div>
        ${renderPrioStrip()}
        <div class="ag-section-title">⏱ Disponibilidad</div>
        <div style="font-size:12px;color:var(--gray);margin-bottom:10px;line-height:1.5">Marca cu&aacute;ndo est&aacute;s ocupado. El algoritmo lo tendr&aacute; en cuenta al planear.</div>
        <div class="av-section">
          ${DAY_KEYS.map(day=>{
            const passed=dayFullyPassed(day);
            return`<div class="av-row${passed?' av-past':''}" id="av-row-${day}"></div>`;
          }).join('')}
        </div>
        <button class="av-calc-btn" onclick="runCalc()" ${!pending.length?'disabled':''}>
          Calcular Escenarios${!pending.length?' (sin pendientes)':''}
        </button>
      </div>
      <div class="ag-section">
        <div class="ag-section-title">◇ Escenarios</div>
        <div id="ag-result">${resultContent}</div>
      </div>`;
    DAY_KEYS.forEach(d=>renderAvDay(d));
  }
}

// ── CALENDAR VIEW ──
let activeView='day',activeDay='Martes',activeVenue='all',activeSec='all',selectedIdx=null,activeMNav='mnav-cartelera';
