// ── ENGINE: Scheduling algorithm ──
// isScreeningBlocked, shuffle, scoreFilm, sortScreensByStrategy,
// computeScenarios (MRV+backtracking), getSuggestions

function isScreeningBlocked(s){
  const av=availability[s.day];if(!av) return false;
  const sStart=toMin(s.time),sEnd=sStart+parseDur(s.duration);
  // Chequeo de solapamiento completo: excluye funciones que ocurran durante el bloque
  return av.blocks.some(b=>sStart<toMin(b.to)&&sEnd>toMin(b.from));
}

// ── ALGORITHM — exhaustive max + MRV + random restarts ──
function shuffle(arr){
  const a=[...arr];
  for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
  return a;
}

// ── Mejora 1: Scoring por película ──
// Pondera cuánto vale incluir una película según rareza, sección y duración
function scoreFilm(title, screens, isPriority, allTitles){
  let score=0;
  // Prioridad explícita: peso máximo
  if(isPriority) score+=100;
  // Unicidad: menos funciones = más difícil de ver = mayor peso
  const n=screens.length;
  if(n===1) score+=40;
  else if(n===2) score+=20;
  else score+=5;
  // Sección única: si es la única película de su sección en la watchlist
  const mySection=screens[0]?.section||'';
  const siblingsInSection=allTitles.filter(t=>{
    if(t===title) return false;
    return FILMS.some(f=>f.title===t&&f.section===mySection);
  });
  if(siblingsInSection.length===0) score+=15;
  // Duración larga: película de >150 min es un compromiso grande, priorizar
  const dur=parseInt(screens[0]?.duration)||0;
  if(dur>150) score+=10;
  return score;
}

// ── Mejora 2: Interval Scheduling — ordenar funciones por conflictos mínimos + fin temprano ──
// Para cada película con múltiples funciones, prioriza la que:
// 1. Conflicta con menos otras funciones de la watchlist (menos bloqueos)
// 2. Termina más temprano (earliest-finish-time: principio clásico de interval scheduling)
function sortScreensByStrategy(screens, allGroups){
  // Precalcular todas las funciones de todas las otras películas
  const allOtherScreenings=allGroups.flatMap(g=>g.screens);
  return [...screens].sort((a,b)=>{
    // Contar cuántas funciones ajenas conflictan con cada opción
    const conflA=allOtherScreenings.filter(s=>s!==a&&screensConflict(a,s)).length;
    const conflB=allOtherScreenings.filter(s=>s!==b&&screensConflict(b,s)).length;
    if(conflA!==conflB) return conflA-conflB; // menos conflictos primero
    // Si empatan, earliest finish time (termina antes = deja más espacio)
    const endA=toMin(a.time)+parseDur(a.duration);
    const endB=toMin(b.time)+parseDur(b.duration);
    return endA-endB;
  });
}

function computeScenarios(titles){
  const pending=titles.filter(t=>!watched.has(t));
  const allPendingTitles=pending; // for section uniqueness check
  const baseGroups=pending.map(t=>{
    const screens=FILMS.filter(f=>f.title===t&&!isScreeningBlocked(f)&&!screeningPassed(f));
    const isPrio=prioritized.has(t);
    const sc=scoreFilm(t,screens,isPrio,allPendingTitles);
    return{title:t,screens,priority:isPrio,score:sc};
  }).filter(g=>g.screens.length>0);
  if(!baseGroups.length) return[];

  // Aplicar Mejora 2: ordenar las funciones de cada película por estrategia
  baseGroups.forEach(g=>{
    if(g.screens.length>1) g.screens=sortScreensByStrategy(g.screens,baseGroups);
  });

  // MRV + Score: restaurado (DP con grupos requiere formulación diferente)
  const mrvGroups=[...baseGroups].sort((a,b)=>{
    if(b.score!==a.score) return b.score-a.score;
    return a.screens.length-b.screens.length;
  });

  // ─────────────────────────────────────────────────────────────────────────
  // ⚠️  FIX CRÍTICO — NO REMOVER (Apr 2026)
  // MAX_NODES_PER_CALL debe aplicarse a AMBAS funciones: findMax/bb y collectAt
  // Sin este límite en findMax, el motor JS de mobile corta la recursión antes
  // que desktop → trueMax diferente entre dispositivos → escenarios inconsistentes
  // (ej: desktop muestra 8 películas por escenario, mobile solo 2)
  // Valor 80000: suficiente para watchlists de hasta ~25 películas en mobile.
  // DEBE declararse ANTES de findMax — const tiene zona muerta temporal (TDZ).
  // ─────────────────────────────────────────────────────────────────────────
  const MAX_NODES_PER_CALL=80000;

  function findMax(groups, mustIncludeAll){
    let best=0;
    let nodes=0;
    function bb(idx,chosen){
      if(++nodes>MAX_NODES_PER_CALL) return;
      const remaining=groups.length-idx;
      if(chosen.length+remaining<=best) return;
      if(idx===groups.length){
        if(!mustIncludeAll){
          if(chosen.length>best) best=chosen.length;
        } else {
          const chosenTitles=new Set(chosen.map(s=>s._title));
          const allPrioritiesIn=groups.every(g=>!g.priority||chosenTitles.has(g.title));
          if(allPrioritiesIn&&chosen.length>best) best=chosen.length;
        }
        return;
      }
      const g=groups[idx];
      for(const s of g.screens){
        if(!chosen.some(c=>screensConflict(c,s))){
          chosen.push({...s,_title:g.title});bb(idx+1,chosen);chosen.pop();
        }
      }
      if(!g.priority) bb(idx+1,chosen);
      else bb(idx+1,chosen);
    }
    bb(0,[]);
    return best;
  }

  const trueMax=findMax(mrvGroups,false);
  const hasPriorities=baseGroups.some(g=>g.priority);
  const maxWithPriorities=hasPriorities?findMax(mrvGroups,true):trueMax;
  const priorityCost=trueMax-maxWithPriorities;

  const seenKeys=new Set();const allScenarios=[];
  let incompatiblePriorities=false;

  function collectAt(groups,targetCount,enforcePriority){
    let nodes=0;
    function backtrack(idx,chosen){
      if(allScenarios.length>=8) return;
      if(++nodes>MAX_NODES_PER_CALL) return; // mismo límite en todos los dispositivos
      if(chosen.length+(groups.length-idx)<targetCount) return;
      if(idx===groups.length){
        if(chosen.length===targetCount){
          if(enforcePriority){
            const ct=new Set(chosen.map(s=>s._title));
            if(!groups.every(g=>!g.priority||ct.has(g.title))) return;
          }
          const key=chosen.map(s=>s._title+'@'+s.day+s.time).sort().join('|');
          if(!seenKeys.has(key)){seenKeys.add(key);allScenarios.push(chosen.map(c=>({...c})));}
        }
        return;
      }
      const g=groups[idx];
      for(const s of g.screens){
        if(!chosen.some(c=>screensConflict(c,s))){
          chosen.push({...s,_title:g.title});backtrack(idx+1,chosen);chosen.pop();
          if(allScenarios.length>=8) return;
        }
      }
      if(!enforcePriority||!g.priority) backtrack(idx+1,chosen);
    }
    backtrack(0,[]);
  }

  const prioritySorted=[...baseGroups].sort((a,b)=>{
    if(a.priority&&!b.priority) return -1;
    if(!a.priority&&b.priority) return 1;
    return a.screens.length-b.screens.length;
  });

  // Phase 1: scenarios WITH priorities — max 4 slots to leave room for diversity
  if(hasPriorities&&maxWithPriorities>0){
    collectAt(prioritySorted,maxWithPriorities,true);
    for(let i=0;i<20&&allScenarios.length<4;i++) collectAt(shuffle(baseGroups),maxWithPriorities,true);
  }

  // Phase 2: if still no scenarios (priorities all conflict with each other), fall back
  if(!allScenarios.length&&hasPriorities){
    incompatiblePriorities=true;
    collectAt(prioritySorted,trueMax,false);
    for(let i=0;i<20&&allScenarios.length<4;i++) collectAt(shuffle(baseGroups),trueMax,false);
  }

  // Phase 3: fill remaining slots with diverse no-priority scenarios
  for(let i=0;i<30&&allScenarios.length<8;i++) collectAt(shuffle(baseGroups),trueMax,false);

  allScenarios.forEach(sc=>sc.sort((a,b)=>a.day_order!==b.day_order?a.day_order-b.day_order:toMin(a.time)-toMin(b.time)));

  // ── Mejora 3: Balanceo por día ──
  // Calcular desviación estándar de películas por día — menor = más balanceado
  function dayBalance(sc){
    const counts={};
    sc.forEach(s=>{counts[s.day]=(counts[s.day]||0)+1;});
    const vals=Object.values(counts);
    if(vals.length<=1) return 0;
    const mean=vals.reduce((a,b)=>a+b,0)/vals.length;
    const variance=vals.reduce((a,v)=>a+Math.pow(v-mean,2),0)/vals.length;
    return Math.sqrt(variance); // 0 = perfectamente balanceado
  }
  // Ordenar: primero los más balanceados (menor desviación estándar)
  allScenarios.sort((a,b)=>dayBalance(a)-dayBalance(b));

  return allScenarios.map(sc=>{
    const included=new Set(sc.map(s=>s._title));
    return{
      schedule:sc,
      excluded:pending.filter(t=>!included.has(t)),
      incompatiblePriorities,
      trueMax,
      maxWithPriorities,
      priorityCost,
      dayBalance:Math.round(dayBalance(sc)*10)/10
    };
  });
}

// ── SUGGESTIONS after saved agenda ──
function getSuggestions(){
  if(!savedAgenda||!savedAgenda.schedule.length) return{};
  const saved=savedAgenda.schedule.filter(s=>!screeningPassed(s));
  if(!saved.length) return{};

  const savedTitles=new Set(saved.map(s=>s._title));
  const byDay={};

  // Excluir siempre: ya en agenda o ya vistas
  const hardExclude=new Set([...savedTitles,...watched]);
  // Para descubrimiento (Bloque 1): también excluir watchlist (ya las conoces)
  const seenDiscover=new Set([...hardExclude,...watchlist]);
  // Para recuperación (Bloque 2): solo excluir hardExclude
  const seenRecovery=new Set([...hardExclude]);

  // ── Slots reservados: todas las películas recientemente quitadas ──
  // Solo muestra "← Restaurar" si el slot original está libre (sin conflicto)
  // Si el slot está ocupado, la película cae a Bloque 2 para buscar slot alternativo
  const currentSaved=savedAgenda?savedAgenda.schedule:[];
  lastRemovedSlots.forEach(rs=>{
    if(savedTitles.has(rs._title)||screeningPassed(rs)) return;
    const slotFree=!currentSaved.some(s=>screensConflict(s,rs));
    if(!slotFree) return; // slot ocupado — cae a Bloque 2
    const day=rs.day;
    if(!byDay[day]) byDay[day]=[];
    byDay[day].push({...rs,gapCtx:'← Restaurar al mismo horario',_isRestored:true});
    hardExclude.add(rs._title);
    seenDiscover.add(rs._title);
    seenRecovery.add(rs._title);
  });

  DAY_KEYS.forEach(day=>{
    const dayItems=saved.filter(s=>s.day===day).sort((a,b)=>toMin(a.time)-toMin(b.time));

    // Calcular huecos del día
    const slots=[];
    if(dayItems.length===0){
      // Día completamente libre — cubre hasta la 1am
      slots.push({start:0,end:25*60,ctx:'Día libre en tu Plan'});
    } else {
      // Antes de la primera
      if(toMin(dayItems[0].time)>60)
        slots.push({start:0,end:toMin(dayItems[0].time)-10,ctx:`Antes de ${(dayItems[0]._title||'').split(' ').slice(0,3).join(' ')}…`});
      // Entre funciones — cualquier hueco positivo (el chequeo fStart/fEnd filtra lo imposible)
      for(let i=0;i<dayItems.length-1;i++){
        const a=dayItems[i],b=dayItems[i+1];
        const aEnd=toMin(a.time)+parseDur(a.duration)+10;
        const bStart=toMin(b.time)-10;
        if(bStart>aEnd)
          slots.push({start:aEnd,end:bStart,ctx:`Entre ${(a._title||'').split(' ').slice(0,3).join(' ')}… y ${(b._title||'').split(' ').slice(0,3).join(' ')}…`});
      }
      // Después de la última — siempre se crea, extiende hasta la 1am
      // Bug fix: el if(lastEnd<22*60) cortaba noches con película tardía (ej: 20:00+90min=22:10 → sin slot)
      const last=dayItems[dayItems.length-1];
      const lastEnd=toMin(last.time)+parseDur(last.duration)+10;
      slots.push({start:lastEnd,end:25*60,ctx:`Después de ${(last._title||'').split(' ').slice(0,3).join(' ')}…`});
    }

    // Bloque 1 — Descubrimiento: películas del festival que quepan en huecos
    if(slots.length){
      FILMS.forEach(f=>{
        if(seenDiscover.has(f.title)||f.is_cortos||screeningPassed(f)||f.day!==day||isScreeningBlocked(f)) return;
        const fStart=toMin(f.time),fEnd=fStart+parseDur(f.duration);
        const slot=slots.find(sl=>fStart>=sl.start&&fEnd<=sl.end&&fEnd-fStart>=20);
        if(slot){
          seenDiscover.add(f.title);seenRecovery.add(f.title);
          if(!byDay[day]) byDay[day]=[];
          byDay[day].push({...f,gapCtx:slot.ctx});
        }
      });
    }

    // Bloque 2 — Recuperación: watchlist no en agenda
    // Mismo criterio de hueco que Bloque 1 (sin buffer adicional)
    // garantiza que una película recién quitada reaparezca si su slot está libre
    [...watchlist].filter(t=>!seenRecovery.has(t)).forEach(t=>{
      FILMS.filter(f=>f.title===t&&f.day===day&&!screeningPassed(f)&&!isScreeningBlocked(f)).forEach(f=>{
        if(seenRecovery.has(f.title)) return;
        const fStart=toMin(f.time),fEnd=fStart+parseDur(f.duration);
        const fitsInSlot=slots.length
          ?slots.some(sl=>fStart>=sl.start&&fEnd<=sl.end&&fEnd-fStart>=20)
          :!saved.some(s=>s.day===day&&toMin(s.time)<fEnd&&fStart<toMin(s.time)+parseDur(s.duration));
        if(fitsInSlot){
          seenRecovery.add(f.title);seenDiscover.add(f.title);
          if(!byDay[day]) byDay[day]=[];
          byDay[day].push({...f,gapCtx:'De tu lista'});
        }
      });
    });
  });
  // ── Ordenar cronológicamente dentro de cada día ──
  Object.keys(byDay).forEach(d=>{
    byDay[d].sort((a,b)=>toMin(a.time)-toMin(b.time));
  });
  return byDay;
}

// ── RENDER FILM LIST ──
// Utility: extraer displayTitle y progSuffix de cualquier título de programa
