// ── ENGINE: Main navigation + renderAgenda + init ──
// switchMainNav, showAgView, renderAgenda, bootstrap

function switchMainNav(id){
  activeMNav=id;
  document.querySelectorAll('.main-nav-tab').forEach(t=>t.classList.remove('on'));
  const el=document.getElementById(id);if(el) el.classList.add('on');
}
function showDayView(){
  activeView='day';
  switchMainNav('mnav-cartelera');
  document.getElementById('nav-row').classList.remove('hidden');
  document.getElementById('filter-bars').style.display='';
  ['hint','cnt','grid'].forEach(id=>{const el=document.getElementById(id);if(el) el.style.display='';});
  document.getElementById('ag-view').classList.remove('visible');
  document.getElementById('agtab').classList.remove('on');
  document.querySelectorAll('.dtab').forEach(t=>t.classList.toggle('on',t.dataset.day===activeDay));
}
function showAgView(){
  activeView='agenda';
  document.getElementById('nav-row').classList.add('hidden');
  document.getElementById('filter-bars').style.display='none';
  ['hint','cnt','grid'].forEach(id=>{const el=document.getElementById(id);if(el) el.style.display='none';});
  const _av=document.getElementById('ag-view');
  _av.classList.add('visible');
  _av.scrollTop=0;
  document.getElementById('agtab').classList.add('on');
  document.querySelectorAll('.dtab').forEach(t=>t.classList.remove('on'));
  renderAgenda();
}

const dtabs=document.getElementById('dtabs');
const DAYS=[{k:'Martes',d:14,lbl:'MAR'},{k:'Miércoles',d:15,lbl:'MIÉ'},{k:'Jueves',d:16,lbl:'JUE'},{k:'Viernes',d:17,lbl:'VIE'},{k:'Sábado',d:18,lbl:'SÁB'},{k:'Domingo',d:19,lbl:'DOM'}];
DAYS.forEach(day=>{
  const cnt=FILMS.filter(f=>f.day===day.k).length;
  const btn=document.createElement('button');
  btn.className='dtab'+(day.k===activeDay?' on':'')+(dayFullyPassed(day.k)?' past':'');
  btn.dataset.day=day.k;
  btn.innerHTML=`<span class="dtab-name">${day.d}</span><span class="dtab-date">${day.lbl}</span>`;
  btn.onclick=()=>{activeDay=day.k;activeVenue='all';activeSec='all';selectedIdx=null;showDayView();render();};
  dtabs.appendChild(btn);
});

function addFbtn(bar,label,val,activeVal,fn){
  const b=document.createElement('button');b.className='fbtn'+(activeVal===val?' on':'');b.innerHTML=label;b.onclick=fn;bar.appendChild(b);
}
function toggleDropdown(id){
  const panel=document.getElementById(id+'-panel');
  const arrow=document.getElementById(id+'-arrow');
  const isOpen=panel.classList.contains('open');
  closeDropdowns();
  if(!isOpen){panel.classList.add('open');if(arrow) arrow.classList.add('open');}
}
function closeDropdowns(){
  document.querySelectorAll('.fdr-panel').forEach(p=>p.classList.remove('open'));
  document.querySelectorAll('.fdr-arrow').forEach(a=>a.classList.remove('open'));
}
function renderVbar(){
  const panel=document.getElementById('vdr-panel');
  const trigBtn=document.getElementById('vdr-btn');
  const lbl=document.getElementById('vdr-label');
  if(!panel) return;
  panel.innerHTML='';
  const dayFilms=FILMS.filter(f=>f.day===activeDay);
  const vs=[...new Set(dayFilms.map(f=>vcfg(f.venue).short))];
  const mkOpt=(html,isOn,cb)=>{
    const b=document.createElement('button');
    b.className='fdr-opt'+(isOn?' on':'');
    b.innerHTML=html;
    b.onclick=e=>{e.stopPropagation();cb();};
    panel.appendChild(b);
  };
  mkOpt(`Todos los lugares <span class="fdr-cnt">${dayFilms.length}</span>`,activeVenue==='all',()=>{activeVenue='all';selectedIdx=null;setHint(null);closeDropdowns();render();});
  vs.forEach(vk=>{
    const cfg=Object.values(VENUES).find(c=>c.short===vk)||VENUES['C. Convenciones'];
    const cnt=dayFilms.filter(f=>vcfg(f.venue).short===vk).length;
    mkOpt(`${cfg.ico} ${vk} <span class="fdr-cnt">${cnt}</span>`,activeVenue===vk,()=>{activeVenue=activeVenue===vk?'all':vk;selectedIdx=null;setHint(null);closeDropdowns();render();});
  });
  if(lbl) lbl.textContent=activeVenue==='all'?'Lugar':activeVenue;
  if(trigBtn) trigBtn.classList.toggle('active',activeVenue!=='all');
}
function renderSbar(){
  const panel=document.getElementById('sdr-panel');
  const trigBtn=document.getElementById('sdr-btn');
  const lbl=document.getElementById('sdr-label');
  if(!panel) return;
  panel.innerHTML='';
  let dayF=FILMS.filter(f=>f.day===activeDay);
  if(activeVenue!=='all') dayF=dayF.filter(f=>vcfg(f.venue).short===activeVenue);
  const secs=[...new Set(dayF.map(f=>f.section))].sort();
  const mkOpt=(html,isOn,cb)=>{
    const b=document.createElement('button');
    b.className='fdr-opt'+(isOn?' on':'');
    b.innerHTML=html;
    b.onclick=e=>{e.stopPropagation();cb();};
    panel.appendChild(b);
  };
  mkOpt(`Todas las categorías <span class="fdr-cnt">${dayF.length}</span>`,activeSec==='all',()=>{activeSec='all';selectedIdx=null;setHint(null);closeDropdowns();render();});
  secs.forEach(sec=>{
    const cnt=dayF.filter(f=>f.section===sec).length;
    mkOpt(`${sec} <span class="fdr-cnt">${cnt}</span>`,activeSec===sec,()=>{activeSec=activeSec===sec?'all':sec;selectedIdx=null;setHint(null);closeDropdowns();render();});
  });
  const shortSec=activeSec==='all'?'Categoría':(activeSec.length>18?activeSec.slice(0,16)+'…':activeSec);
  if(lbl) lbl.textContent=shortSec;
  if(trigBtn) trigBtn.classList.toggle('active',activeSec!=='all');
}
function setHint(film){
  const el=document.getElementById('hint');
  if(!film){el.textContent='';el.classList.remove('active');el.style.padding='0 18px';return;}
  const end=toMin(film.time)+parseDur(film.duration)+10;
  el.textContent=`⏱ Horario: ${minToStr(toMin(film.time)-10)} – ${minToStr(end)} · Toca de nuevo para deseleccionar`;
  el.style.padding='8px 18px';
  el.classList.add('active');
}
function onCardClick(idx,vis){
  if(selectedIdx===idx){selectedIdx=null;setHint(null);}else{selectedIdx=idx;setHint(vis[idx]);}
  applyStates(vis);
}
function applyStates(vis){
  document.querySelectorAll('.card').forEach((card,i)=>{
    card.classList.remove('selected','conflict');
    if(selectedIdx===null) return;
    if(i===selectedIdx) card.classList.add('selected');
    else{
      const fStart=toMin(vis[i].time),sel=vis[selectedIdx];
      const s=toMin(sel.time)-10,e=toMin(sel.time)+parseDur(sel.duration)+10;
      if(fStart>s&&fStart<e) card.classList.add('conflict');
    }
  });
}
const expandedProgs=new Set(JSON.parse(sessionStorage.getItem('ficci65_exp')||'[]'));
function toggleExpand(el,e){
  e.stopPropagation();
  const card=el.closest('.card');
  const listEl=card.querySelector('.c-film-list,.c-title-pills');
  const arrow=el.querySelector('.c-expand-arrow');
  if(!listEl) return;
  listEl.classList.toggle('visible');arrow.classList.toggle('open');
  const open=listEl.classList.contains('visible');
  el.querySelector('span:first-child').textContent=open?'Ocultar programa':'Ver programa';
  const title=card.dataset.title;
  if(title){if(open) expandedProgs.add(title);else expandedProgs.delete(title);}
  try{sessionStorage.setItem('ficci65_exp',JSON.stringify([...expandedProgs]));}catch(er){}
}
function restoreExpand(){
  if(!expandedProgs.size) return;
  document.querySelectorAll('.card.program[data-title]').forEach(card=>{
    if(!expandedProgs.has(card.dataset.title)) return;
    const listEl=card.querySelector('.c-film-list,.c-title-pills');
    const arrow=card.querySelector('.c-expand-arrow');
    const lbl=card.querySelector('.c-expand span:first-child');
    if(listEl){listEl.classList.add('visible');if(arrow) arrow.classList.add('open');if(lbl) lbl.textContent='Ocultar programa';}
  });
}


loadState();updateAgTab();render();
document.addEventListener('click',e=>{if(!e.target.closest('.fdr-wrap')) closeDropdowns();});
